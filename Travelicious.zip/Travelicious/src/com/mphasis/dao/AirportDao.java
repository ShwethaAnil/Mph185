package com.mphasis.dao;

import java.sql.SQLException;
import java.util.List;

import com.mphasis.pojos.Airport;

public interface AirportDao {
	public List<Airport> retrieveAirports();
	public int insertAirportDetails(Airport airport);
	public int updateAirportDetails(String airportid, String airportname, String airlineid);
	public int deleteAirlineDetails(String airportid);
	public Airport retrieveAirportByID(String airportid)throws SQLException;

}
