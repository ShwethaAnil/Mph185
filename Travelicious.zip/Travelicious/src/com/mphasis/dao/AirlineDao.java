package com.mphasis.dao;

import java.sql.SQLException;
import java.util.List;

import com.mphasis.pojos.Airline;

public interface AirlineDao {

	public List<Airline> retrieveAirlines();
	public int addAirline(Airline airline);
	public int updateAirline(String airlineid,String airlinename);
	public int deleteAirline(String airlineid);
	public Airline retrieveAirlineByID(String airlineid)throws SQLException;
}
