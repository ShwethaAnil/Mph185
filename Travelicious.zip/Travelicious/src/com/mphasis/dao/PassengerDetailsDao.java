package com.mphasis.dao;

import java.sql.SQLException;
import java.util.List;

import com.mphasis.pojos.PassengerDetails;


public interface PassengerDetailsDao {
	
	public List<PassengerDetails> retrievePassengers();
	public int addPassenger(PassengerDetails p);
	public int updatePassenger(String passengerid, int age);
	public int deletePassenger(String passengerid);
	public PassengerDetails retrievePassengerById(String passengerid)throws SQLException ;

}
