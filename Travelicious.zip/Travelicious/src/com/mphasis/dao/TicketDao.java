package com.mphasis.dao;

import java.sql.SQLException;
import java.util.List;

import com.mphasis.pojos.Ticket;


public interface TicketDao {

	public List<Ticket> retrieveTickets();
	public int addTicket(Ticket t);
	public int updateStatusByTicketId(String ticketid, String status);
	public int updateCostByTicketId(String ticketid, double cost) throws SQLException;
	public int deleteTicket(String ticketid);
	public Ticket retrieveTicketById(String ticketid)throws SQLException ;
}

