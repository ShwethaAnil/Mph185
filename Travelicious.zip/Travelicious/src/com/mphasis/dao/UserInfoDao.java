package com.mphasis.dao;

import java.sql.SQLException;

import com.mphasis.pojos.UserInformation;

public interface UserInfoDao {
	public int addUser(UserInformation userInformation);

	public UserInformation retrieveUserInfoUsingEmail(String email) throws SQLException;
	public UserInformation retrieveUserInfoUsingUserName(String username) throws SQLException;

	int updateAddressUsingEmail(String email, String address);

	int updateEmailUsingUserId(String userid, String email);

	public int updatePhoneNumberUsingEmail(String email, long number);

	UserInformation retrieveUserInfoUsingUserId(String userid) throws SQLException;

	int updatePasswordUsingId(String id, String password);

}