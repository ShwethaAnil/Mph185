package com.mphasis.dao;

import java.sql.SQLException;
import java.util.List;

import com.mphasis.dto.SearchFlightDetails;
import com.mphasis.pojos.Flight;

public interface FlightDao {
	
    public List<Flight> retrieveFlights();
	public int insertFlight(Flight f);
	public int updateSeatsByFlightId(String flightId, int numOfSeats);
	public int updateFareByFlightId(String flightId,double minFare);
	public int updateClassByFlightId(String flightId,String typeOfClass,double minFare);
	public int deleteFlight(String flightId);
	public Flight retrieveFlightById(String flightId)throws SQLException;
	public List<SearchFlightDetails> retriveDetailsBySourceDestandDate(String source,String destination,String deptdate) throws SQLException;
}
