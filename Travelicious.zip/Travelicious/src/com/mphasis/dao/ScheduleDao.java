package com.mphasis.dao;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import com.mphasis.pojos.Schedule;

public interface ScheduleDao {
	public int insertSchedule(Schedule s);
    public int deleteSchedule(String scheduleId);
	public int updateSchedule(String ScheduleId, LocalDate deptDate,LocalDate arrDate, LocalTime deptTime, LocalTime arrTime, String flightId );	
	public Schedule retrieveScheduleById(String scheduleId);
	public List<Schedule> retrieveSchedules();
	public Schedule getScheduleByDept(String deptDate) throws SQLException;
	int updateScheduleTime(String scheduleId,  LocalTime deptTime,LocalTime arrTime);

}
