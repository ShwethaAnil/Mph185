package com.mphasis.dao;

import java.sql.SQLException;
import java.util.List;

import com.mphasis.dto.ConfirmBooking;

public interface ConfirmBookingDao {
	
	public List<ConfirmBooking> retriveticketDetailsById(String userid) throws SQLException;

}
