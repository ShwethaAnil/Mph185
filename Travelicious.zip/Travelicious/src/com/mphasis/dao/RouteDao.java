package com.mphasis.dao;

import java.util.List;

import com.mphasis.pojos.Route;

public interface RouteDao {
	public int insertRoute(Route r);
    public int deleteRoute(String routeId);
	public Route retrieveRouteById(String routeId);
	public int editRoute(String routeid, String source, String destination, String scheduleId);
	public List<Route> retrieveRoutes();
	public Route getRouteBySourceDest(String source, String destination);

}
