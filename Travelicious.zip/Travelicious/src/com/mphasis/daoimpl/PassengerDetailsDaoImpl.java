package com.mphasis.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.dao.PassengerDetailsDao;
import com.mphasis.pojos.PassengerDetails;
import com.mphasis.util.DbUtil;

public class PassengerDetailsDaoImpl implements PassengerDetailsDao {

	Connection con = null;
	public PassengerDetailsDaoImpl() {
		con=DbUtil.openConnection();
	}
	@Override
	public List<PassengerDetails> retrievePassengers() {
		List<PassengerDetails> pass = new ArrayList<>();
		Statement st;
		try {
			 st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from passengerdetails");
			while(rs.next()) {
				PassengerDetails p = new PassengerDetails();
				p.setPassengerid(rs.getString("passengerid"));
				p.setPassengername(rs.getString("passengername"));
				p.setAge(rs.getInt("age"));
				p.setGender(rs.getString("gender"));
				p.setPassportnumber(rs.getString("passportnumber"));
				p.setUserid(rs.getString("user_id"));
				pass.add(p);
			}
		} catch (SQLException e) {
			e.getMessage();
		}	
		return pass;
	}

	@Override
	public int addPassenger(PassengerDetails p) {
		int i = 0;
		try {
			String query= "insert into passengerdetails values(?,?,?,?,?,?)";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, p.getPassengerid());
			pst.setString(2, p.getPassengername());
			pst.setInt(3, p.getAge());
			pst.setString(4, p.getGender());
			pst.setString(5, p.getPassportnumber());
			pst.setString(6, p.getUserid());
			
			i = pst.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int updatePassenger(String passengerid, int age) {
		int i = 0;
		try {
			String query= "update passengerdetails set age=? where passengerid=?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, age);
			pst.setString(2, passengerid);
			
			i = pst.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int deletePassenger(String passengerid) {
		int i = 0;
		try {
			String query= "delete from passengerdetails where passengerid=?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, passengerid);
			i = pst.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public PassengerDetails retrievePassengerById(String passengerid) throws SQLException {
		PassengerDetails p = new PassengerDetails();
		PreparedStatement pst = null;
		ResultSet rs = null;
		
		try {
			String query= "select * from passengerdetails where passengerid=?";
			pst = con.prepareStatement(query);
			pst.setString(1, passengerid);
			rs=pst.executeQuery();
			if(rs.next()) {
				p.setPassengerid(rs.getString("passengerid"));
				p.setPassengername(rs.getString("passengername"));
				p.setAge(rs.getInt("age"));
				p.setGender(rs.getString("gender"));
				p.setPassportnumber(rs.getString("passportnumber"));
				p.setUserid(rs.getString("user_id"));
		}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			rs.close();
			pst.close();
		}
		return p;
	}
	
	

}
