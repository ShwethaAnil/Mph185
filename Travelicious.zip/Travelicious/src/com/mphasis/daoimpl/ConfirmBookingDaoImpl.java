package com.mphasis.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.dao.ConfirmBookingDao;
import com.mphasis.dto.ConfirmBooking;
import com.mphasis.util.DbUtil;

public class ConfirmBookingDaoImpl implements ConfirmBookingDao {
	
	Connection con = null;
	public ConfirmBookingDaoImpl() {
		con = DbUtil.openConnection();
	}

	public List<ConfirmBooking> retriveticketDetailsById(String userId) throws SQLException {
		List<ConfirmBooking> bookings = new ArrayList<>();
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			String query = "select a.airlinename, f.flightid, t.ticketid,t.status, s.deptdate, r.source, r.destination , p.passengername, p.passportnumber, p.age, p.gender, u.user_id from\r\n" + 
					"AIRLINES a, flight f, ticket t, schedule s,route r,passengerdetails p, user_information u where a.AIRLINEID=f.AIRLINEID and f.FLIGHTID=s.FLIGHTID and\r\n" + 
					"s.SCHEDULEID = r.SCHEDULEID and p.USER_ID = u.USER_ID and t.PASSENGERID = p.PASSENGERID and t.flightid=f.flightid and u.USER_ID=?";

			pst= con.prepareStatement(query);
			pst.setString(1,userId);
			rs= pst.executeQuery();
			while(rs.next()) {
				ConfirmBooking c= new ConfirmBooking();
				c.setAirlinename(rs.getString("airlinename"));
				c.setFlightid(rs.getString("flightid"));
				c.setTicketid(rs.getString("ticketid"));
				c.setStatus(rs.getString("status"));
				c.setDeptdate(rs.getDate("deptdate").toLocalDate());
				c.setSource(rs.getString("source"));
				c.setDestination(rs.getString("destination"));
				c.setPassengername(rs.getString("passengername"));
				c.setPassportnumber(rs.getString("passportnumber"));
				c.setAge(rs.getInt("age"));
				c.setGender(rs.getString("gender"));
				c.setUserid(rs.getString("user_id"));
				bookings.add(c);	
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
			
		}finally {
			rs.close();
			pst.close();
		}
				
		return bookings;
	}

}
