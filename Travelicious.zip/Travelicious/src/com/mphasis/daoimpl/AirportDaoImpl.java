package com.mphasis.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.dao.AirportDao;
import com.mphasis.pojos.Airport;
import com.mphasis.util.DbUtil;

public class AirportDaoImpl implements AirportDao {

	Connection con = null;

	public AirportDaoImpl() {
		con = DbUtil.openConnection();

	}

	@Override
	public List<Airport> retrieveAirports() {
		List<Airport> airports = new ArrayList<>();


		Statement st;
		try {
			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from airport");
			while (rs.next()) {

				Airport a = new Airport();

				a.setAirportId(rs.getString("airportid"));
				a.setAirportName(rs.getString("airportname"));
				a.setCountry(rs.getString("country"));
				a.setCity(rs.getString("city"));
				a.setAirlineId(rs.getString("airlineid"));
				airports.add(a);

		      }

		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		return airports;
	
	}

	@Override
	public int insertAirportDetails(Airport airport) {
		int i = 0;
		try {
		String query = "insert into airport values(?,?,?)";
		PreparedStatement pst = con.prepareStatement(query);
		pst.setString(1,airport.getAirportId());
		pst.setString(2,airport.getAirlineId());
		pst.setString(3,airport.getAirportName());
		pst.setString(4,airport.getCountry());
		pst.setString(5,airport.getCity());

		i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int updateAirportDetails(String airportid, String airportname, String airlineid) {
		int i =0;
		try {
		String query ="update airport set  airportname=?,airlineid=? where airportid=?";
		PreparedStatement pst = con.prepareStatement(query);

		pst.setString(1, airportname);
		pst.setString(2, airlineid);
		pst.setString(3, airportid);
		
		i=pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int deleteAirlineDetails(String airportid) {
		int i =0;
		try {

			String query ="delete from airport where airportid=?";
			PreparedStatement pst = con.prepareStatement(query);
			

			pst.setString(1, airportid);
			i=pst.executeUpdate();

			} catch (SQLException e) {

				e.printStackTrace();

			}
			return i;
	}

	@Override
	public Airport retrieveAirportByID(String airportid) throws SQLException {
		Airport a= new Airport();

		PreparedStatement pst = null;
		ResultSet rs = null;

		try {
			String query = "select * from airport where airportid=?";
			pst= con.prepareStatement(query);
			pst.setString(1, airportid);
			rs= pst.executeQuery();
			if(rs.next()) {

				a.setAirportId(rs.getString("airportid"));
				a.setAirportName(rs.getString("airportName"));
				a.setCountry(rs.getString("country"));
				a.setCity(rs.getString("city"));
				a.setAirlineId(rs.getString("airlineid"));

			}

		}catch(SQLException e) {
			e.printStackTrace();
		}finally {

			rs.close();

			pst.close();
		}
		return a;
	}

}
