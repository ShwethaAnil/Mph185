package com.mphasis.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.dao.ScheduleDao;
import com.mphasis.pojos.Schedule;
import com.mphasis.util.DbUtil;

public class ScheduleDaoImpl implements ScheduleDao {
	Connection con = null;
	
	 public ScheduleDaoImpl() {
		 con = DbUtil.openConnection();
		
	}
	@Override
	public int insertSchedule(Schedule s) {
		// TODO Auto-generated method stub
		
         int i =0;
		  
		
		try {
			String query = "insert into schedule values(?,?,?,?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1,s.getScheduleId());
			pstmt.setDate(2, java.sql.Date.valueOf(s.getDeptdate()));
			pstmt.setDate(3, java.sql.Date.valueOf(s.getArrdate()));
			pstmt.setTime(4, java.sql.Time.valueOf(s.getDepttime()));
			pstmt.setTime(5, java.sql.Time.valueOf(s.getArrtime()));
			pstmt.setString(6,s.getFlightid());
			 i =pstmt.executeUpdate();
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};	
		return i;
	
	}

	@Override
	public int deleteSchedule(String scheduleId) {
		// TODO Auto-generated method stub
	    int i =0;
		
			try {
				String query = "delete from schedule  where scheduleid=?";
				PreparedStatement pstmt= con.prepareStatement(query);	
				pstmt.setString(1,scheduleId);
				
				i= pstmt.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return i;
			
		}
	

	

	@Override
	public int updateSchedule(String ScheduleId, LocalDate deptDate, LocalDate arrDate, LocalTime deptTime, LocalTime arrTime,
			String flightId) {
      int i =0;
		
		try {
			String query = "update schedule set deptdate=?, arrdate=?, depttime=?, arrtime=?, flightid=? where scheduleid=?";
			PreparedStatement pstmt= con.prepareStatement(query);
			
			pstmt.setDate(1,java.sql.Date.valueOf(deptDate));
			pstmt.setDate(2,java.sql.Date.valueOf(arrDate));
			pstmt.setTime(3,java.sql.Time.valueOf(deptTime));
			pstmt.setTime(4, java.sql.Time.valueOf(arrTime));
			pstmt.setString(5, flightId);
			pstmt.setString(6, ScheduleId);
			i= pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}
	

	@Override
	public Schedule retrieveScheduleById(String scheduleId) {
		// TODO Auto-generated method stub
		Schedule s=new Schedule();
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			String query="select * from schedule where scheduleid=?";
			 pstmt=con.prepareStatement(query);
			 pstmt.setString(1, scheduleId);
			 rs=pstmt.executeQuery();
			 if(rs.next()) {
					s.setScheduleId(rs.getString("scheduleid"));
					s.setDeptdate(rs.getDate("deptdate").toLocalDate());
					s.setArrdate(rs.getDate("arrdate").toLocalDate());
					s.setDepttime(rs.getTime("depttime").toLocalTime());
					s.setArrtime(rs.getTime("arrtime").toLocalTime());
					s.setFlightid(rs.getString("flightid"));
					
				}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return s;
	}
	@Override
	public List<Schedule> retrieveSchedules() {
		// TODO Auto-generated method stub
		List<Schedule> schedules = new ArrayList<>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs=stmt.executeQuery("Select * from schedule");
			while(rs.next())
			{
				Schedule s = new Schedule();
				s.setScheduleId(rs.getString("scheduleid"));
				s.setDeptdate(rs.getDate("deptdate").toLocalDate());
				s.setArrdate(rs.getDate("arrdate").toLocalDate());
				s.setDepttime(rs.getTime("depttime").toLocalTime());
				s.setArrtime(rs.getTime("arrtime").toLocalTime());
				s.setFlightid(rs.getString("flightid"));
				schedules.add(s);
				
			}
			
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return schedules;
		
		
	}
	@Override
	public Schedule getScheduleByDept(String deptDate) throws SQLException {
		// TODO Auto-generated method stub
		
		Schedule s=new Schedule();
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			System.out.print("working");

			String query="select * from schedule where TRUNC(deptdate)=TO_DATE(?,'YYYY-MM-DD')";
			 pstmt=con.prepareStatement(query);
			 pstmt.setString(1, deptDate);
			 rs=pstmt.executeQuery();
			if(rs.next()) {
				s.setScheduleId(rs.getString("scheduleid"));
				s.setDeptdate(rs.getDate("deptdate").toLocalDate());
				s.setArrdate(rs.getDate("arrdate").toLocalDate());
				s.setDepttime(rs.getTime("depttime").toLocalTime());
				s.setArrtime(rs.getTime("arrtime").toLocalTime());
				s.setFlightid(rs.getString("flightid"));
				System.out.print("working");
			}
		}catch(SQLException e ) {
			e.printStackTrace();
		}finally {
			
			rs.close();
			pstmt.close();
	
		}
		return s;
	}
	@Override
	public int updateScheduleTime(String scheduleId, LocalTime deptTime, LocalTime arrTime) {
		  int i =0;
			
			try {
				String query = "update schedule set  depttime=?, arrtime=? where scheduleid=?";
				PreparedStatement pstmt= con.prepareStatement(query);
				
				pstmt.setTime(1,java.sql.Time.valueOf(deptTime));
				pstmt.setTime(2, java.sql.Time.valueOf(arrTime));
				pstmt.setString(3, scheduleId);
				i= pstmt.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return i;
			
		}

}
