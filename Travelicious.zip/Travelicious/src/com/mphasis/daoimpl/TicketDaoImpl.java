package com.mphasis.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.dao.TicketDao;
import com.mphasis.pojos.Ticket;
import com.mphasis.util.DbUtil;;;

public class TicketDaoImpl implements TicketDao {
	Connection con = null;
	public TicketDaoImpl() {
		con=DbUtil.openConnection();
	}

	@Override
	public List<Ticket> retrieveTickets() {
      List<Ticket> tickets = new ArrayList<>();
		
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from ticket");
			while(rs.next()) {
				Ticket t = new Ticket();
				t.setTicketid(rs.getNString("ticketid"));
				t.setStatus(rs.getString("status"));
				t.setSeatno(rs.getInt("seatno"));
				t.setPassengerid(rs.getString("passengerid"));
				t.setFlightid(rs.getString("flightid"));
				t.setCost(rs.getDouble("cost"));
				tickets.add(t);
			}
		} catch (SQLException e) {
			e.getMessage();
		}	
		return tickets;
	}

	@Override
	public int addTicket(Ticket t) {
		int i = 0;
		try {
			String query= "insert into ticket values(?,?,?,?,?,?)";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, t.getTicketid());
			pst.setString(2, t.getStatus());
			pst.setInt(3, t.getSeatno());
			pst.setString(4, t.getPassengerid());
			pst.setString(5, t.getFlightid());
			pst.setDouble(6, t.getCost());
			i = pst.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int updateStatusByTicketId(String ticketid, String status) {
		int i = 0;
		try {
			String query= "update ticket set status=? where ticketid=?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, status);
			pst.setString(2, ticketid);
			
			i = pst.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
	
	@Override
	public int updateCostByTicketId(String ticketid, double cost) throws SQLException {
		int i=0;
			
			try {
				String query= "update ticket set cost=? where ticketid=?";
				PreparedStatement pst;
				pst = con.prepareStatement(query);
				pst.setDouble(1, cost);
				pst.setString(2, ticketid);
				i= pst.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		return i;
	}

	@Override
	public int deleteTicket(String ticketid) {
		int i = 0;
		try {
			String query= "delete from ticket where ticketid=?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, ticketid);
			i = pst.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public Ticket retrieveTicketById(String ticketId) throws SQLException {
		Ticket t = new Ticket();
		PreparedStatement pst = null;
		ResultSet rs = null;
		
		try {
			String query= "select * from ticket where ticketid=?";
			pst = con.prepareStatement(query);
			pst.setString(1, ticketId);
			rs=pst.executeQuery();
			if(rs.next()) {
				t.setTicketid(rs.getNString("ticketid"));
				t.setStatus(rs.getString("status"));
				t.setSeatno(rs.getInt("seatno"));
				t.setPassengerid(rs.getString("passengerid"));
				t.setFlightid(rs.getString("flightid"));
				t.setCost(rs.getDouble("cost"));
		}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			rs.close();
			pst.close();
		}
		return t;
	}
	

}
