package com.mphasis.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.dao.AirlineDao;
import com.mphasis.pojos.Airline;
import com.mphasis.util.DbUtil;

public class AirlineDaoImpl implements AirlineDao {

	Connection con = null;

	public AirlineDaoImpl() {
		con = DbUtil.openConnection();

	}

	@Override
	public List<Airline> retrieveAirlines() {
		List<Airline> airlines = new ArrayList<>();
		Statement st;
		try {
			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from airlines");
			while (rs.next()) {

				Airline a = new Airline();
				a.setAirlineId(rs.getString("airlineid"));
				a.setAirlineName(rs.getString("airlinename"));
				airlines.add(a);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return airlines;
	}

	@Override
	public int addAirline(Airline airline) {
		int i = 0;
		try {
			String query = "insert into airlines values(?,?)";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, airline.getAirlineId());
			pst.setString(2, airline.getAirlineName());
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int updateAirline(String airlineid, String airlinename) {
		int i = 0;
		try {
			String query = "update airlines set airlinename=? where airlineid=?";
			PreparedStatement pst = con.prepareStatement(query);

			pst.setString(1, airlinename);
			pst.setString(2, airlineid);

			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int deleteAirline(String airlineid) {
		int i = 0;
		try {

			String query = "delete from airlines where airlineid=?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, airlineid);
			i = pst.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();

		}
		return i;
	}

	@Override
	public Airline retrieveAirlineByID(String airlineid) throws SQLException {
		Airline a = new Airline();

		PreparedStatement pst = null;
		ResultSet rs = null;

		try {
			String query = "select * from airlines where airlineid=?";
			pst = con.prepareStatement(query);
			pst.setString(1, airlineid);
			rs = pst.executeQuery();
			if (rs.next()) {

				a.setAirlineId(rs.getString("airlineid"));
				a.setAirlineName(rs.getString("airlinename"));

			}

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {

			rs.close();

			pst.close();
		}
		return a;
	}

}
