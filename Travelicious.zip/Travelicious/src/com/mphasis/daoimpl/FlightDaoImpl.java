package com.mphasis.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.dao.FlightDao;
import com.mphasis.dto.SearchFlightDetails;
import com.mphasis.pojos.Flight;
import com.mphasis.util.DbUtil;



public class FlightDaoImpl implements FlightDao{
	
	Connection con = null;
	public FlightDaoImpl() {
		con = DbUtil.openConnection();
	}

	@Override
	public List<Flight> retrieveFlights() {
      List<Flight> flights = new ArrayList<>();
		
		Statement st;
		try {
			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from flight");
			while (rs.next()) {
				Flight f = new Flight();
				f.setFlightId(rs.getString("flightid"));
				f.setNumOfSeats(rs.getInt("numofseats"));
				f.setTypeOfClass(rs.getString("typeofclass"));
				f.setMinFare(rs.getDouble("minfare"));
				f.setAirlineId(rs.getString("airlineid"));
				
				flights.add(f);
					
		      }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return flights;
	}
		
	

	@Override
	public int insertFlight(Flight f) {
		int i = 0;
		try {
		String query = "insert into flight values(?,?,?,?,?)";
		PreparedStatement pst = con.prepareStatement(query);
		pst.setString(1,f.getFlightId());
		pst.setInt(2,f.getNumOfSeats());
		pst.setString(3,f.getTypeOfClass());
		pst.setDouble(4, f.getMinFare());
		pst.setString(5,f.getAirlineId());
		
		i = pst.executeUpdate();
		
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int updateSeatsByFlightId(String flightId, int numOfSeats) {
		int i =0;
		try {
		String query ="update flight set numofseats=? where flightid=?";
		PreparedStatement pst = con.prepareStatement(query);
	
		pst.setInt(1, numOfSeats);
		
		pst.setString(2, flightId);
		
		i=pst.executeUpdate();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int deleteFlight(String flightId) {
		int i =0;
		try {
			String query ="delete from flight where flightid=?";
			PreparedStatement pst = con.prepareStatement(query);
		
			
			pst.setString(1, flightId);
			
			i=pst.executeUpdate();
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return i;
	}

	@Override
	public Flight retrieveFlightById(String flightId) throws SQLException {
		Flight f= new Flight();
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			String query = "select * from flight where flightid=?";
			pst= con.prepareStatement(query);
			pst.setString(1, flightId);
			rs= pst.executeQuery();
			if(rs.next()) {
				f.setFlightId(rs.getString("flightid"));
				f.setNumOfSeats(rs.getInt("numofseats"));
				f.setTypeOfClass(rs.getString("typeofclass"));
				f.setMinFare(rs.getDouble("minFare"));
				f.setAirlineId(rs.getString("airlineid"));
				
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
			
		}finally {
			rs.close();
			pst.close();
		}
				
		
		return f;
	}

	

	@Override
	public int updateFareByFlightId(String flightId, double minFare) {
		int i =0;
		try {
		String query ="update flight set minfare=? where flightid=?";
		PreparedStatement pst = con.prepareStatement(query);
	
		pst.setDouble(1, minFare);
		
		pst.setString(2, flightId);
		
		i=pst.executeUpdate();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int updateClassByFlightId(String flightId, String typeOfClass,double minFare) {
		int i =0;
		try {
		String query ="update flight set typeofclass=?,minfare=? where flightid=?";
		PreparedStatement pst = con.prepareStatement(query);
	
		pst.setString(1, typeOfClass);
		pst.setDouble(2, minFare);
		pst.setString(3, flightId);
		
		i=pst.executeUpdate();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}

	@Override
	public List<SearchFlightDetails> retriveDetailsBySourceDestandDate(String source, String destination,
			String deptdate) throws SQLException {
		List<SearchFlightDetails> searchFlights = new ArrayList<>();
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			String query = "select a.airlinename, f.flightid, s.deptdate, s.depttime, s.arrdate, s.arrtime , r.source, r.destination ,f.MINFARE from\r\n" + 
					"AIRLINES a, flight f, schedule s,route r where a.AIRLINEID=f.AIRLINEID and f.FLIGHTID=s.FLIGHTID and\r\n" + 
					"s.SCHEDULEID = r.SCHEDULEID and TRUNC(s.DEPTDATE)=TO_DATE(?,'YYYY-MM-DD') and\r\n" + 
					"r.SOURCE=? and r.DESTINATION=?";
			pst= con.prepareStatement(query);
			pst.setString(1,deptdate);
			pst.setString(2, source);
			pst.setString(3, destination);
			rs= pst.executeQuery();
			while(rs.next()) {
				SearchFlightDetails s= new SearchFlightDetails();
				s.setAirlinename(rs.getString("airlinename"));
				s.setFlightid(rs.getString("flightid"));
				s.setDeptdate(rs.getDate("deptdate").toLocalDate());
				s.setDepttime(rs.getTime("depttime").toLocalTime());
				s.setArrdate(rs.getDate("arrdate").toLocalDate());
				s.setArrtime(rs.getTime("arrtime").toLocalTime());
				s.setSource(rs.getString("source"));
				s.setDestination(rs.getString("destination"));
				s.setMinfare(rs.getDouble("minfare"));
				searchFlights.add(s);	
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
			
		}finally {
			rs.close();
			pst.close();
		}
				
		return searchFlights;
	}


	}

	


