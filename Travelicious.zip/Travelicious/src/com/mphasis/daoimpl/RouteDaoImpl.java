package com.mphasis.daoimpl;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.dao.RouteDao;
import com.mphasis.pojos.Route;
import com.mphasis.util.DbUtil;

public class RouteDaoImpl implements RouteDao {
	Connection con = null;
	
	 public RouteDaoImpl() {
		 con = DbUtil.openConnection();
		
	}
	public int insertRoute(Route r) {
		// TODO Auto-generated method stub
		
         int i =0;
		  
 		
 		try {
 			String query = "insert into Route values(?,?,?,?)";
 			PreparedStatement pstmt = con.prepareStatement(query);
 			pstmt.setString(1,r.getRouteid());
 			pstmt.setString(2, r.getSource());
 			pstmt.setString(3,r.getDestination());
 			pstmt.setString(4,r.getscheduleId());
 		
 			
 			 i =pstmt.executeUpdate();
 			

 		} catch (SQLException e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		};	
 		return i;
	}

	@Override
	public int deleteRoute(String routeid) {
		// TODO Auto-generated method stub
		
       int i =0;
		
		try {
			String query = "delete from  route  where routeid=?";
			PreparedStatement pstmt= con.prepareStatement(query);	
			pstmt.setString(1,routeid);
			
			i= pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return i;
	}
	

	@Override
	public Route retrieveRouteById(String routeId) {
		// TODO Auto-generated method stub
		
		Route r=new Route();
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			String query="select * from route where routeid=?";
			 pstmt=con.prepareStatement(query);
			 pstmt.setString(1, routeId);
			 rs=pstmt.executeQuery();
			if(rs.next()) {
				r.setRouteid(rs.getString("routeid"));
				r.setSource(rs.getString("source"));
				r.setDestination(rs.getString("destination"));
				r.setScheduleId(rs.getString("scheduleid"));
				
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return r;
	}

	@Override
	public int editRoute(String routeId, String source, String destination, String scheduleId) {
		// TODO Auto-generated method stub
int i =0;
		
		try {
			String query = "update route set source=?, destination=?, scheduleid=? where routeid=?";
			PreparedStatement pstmt= con.prepareStatement(query);
			
			pstmt.setString(1,source);
			pstmt.setString(2,destination);
			pstmt.setString(3, scheduleId);
			pstmt.setString(4,routeId);
			i= pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
		
	}
	public List<Route> retrieveRoutes() {
		List<Route> routes = new ArrayList<>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs=stmt.executeQuery("Select * from route");
			while(rs.next())
			{
				Route r = new Route();
				r.setRouteid(rs.getString("routeid"));
				r.setSource(rs.getString("source"));
				r.setDestination(rs.getString("destination"));
				r.setScheduleId(rs.getString("scheduleid"));
				routes.add(r);
				
			}
			
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return routes;
		
		
	}
	@Override
	public Route getRouteBySourceDest(String source, String destination) {
		// TODO Auto-generated method stub

	
			// TODO Auto-generated method stub
			
			Route r=new Route();
			PreparedStatement pst=null;
			ResultSet rs=null;
			try {
				String query="select * from route where source=? and destination=?";
				 pst=con.prepareStatement(query);
				 pst.setString(1, source);
				 pst.setString(2, destination);
				 rs=pst.executeQuery();
				if(rs.next()) {
					r.setRouteid(rs.getString("routeid"));
					r.setSource(rs.getString("source"));
					r.setDestination(rs.getString("destination"));
					r.setScheduleId(rs.getString("scheduleid"));
					
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}finally {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					pst.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return r;
		}
}
