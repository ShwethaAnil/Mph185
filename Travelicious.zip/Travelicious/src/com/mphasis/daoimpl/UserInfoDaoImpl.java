package com.mphasis.daoimpl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mphasis.dao.UserInfoDao;
import com.mphasis.pojos.UserInformation;
import com.mphasis.util.DbUtil;

public class UserInfoDaoImpl implements UserInfoDao {
	Connection con = null;

	public UserInfoDaoImpl() {

		con = DbUtil.openConnection();

	}

	@Override
	public int addUser(UserInformation userInformation) {
		int i = 0;
		try {
			String sql = "insert into user_information values(?,?,?,?,?,?,?,?)";
			PreparedStatement pst = con.prepareStatement(sql);
			// pst.setInt(1, m.getUserid());
			pst.setString(1, userInformation.getUserId());
			pst.setString(2, userInformation.getUserName());
			pst.setString(3, userInformation.getEmail());
			pst.setDate(4, Date.valueOf(userInformation.getDob()));
			pst.setLong(5, userInformation.getPhnNo());
			pst.setString(6, userInformation.getAddress());
			pst.setString(7, userInformation.getPassword());
			pst.setString(8, userInformation.getUserType());
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public UserInformation retrieveUserInfoUsingEmail(String email) throws SQLException {

		UserInformation userInformation = new UserInformation();
		PreparedStatement pst = null;
		ResultSet rs = null;

		String query = "select * from user_information where email=?";
		try {
			pst = con.prepareStatement(query);
			pst.setString(1, email);
			rs = pst.executeQuery();

			if (rs.next()) {

				userInformation.setUserId(rs.getString("user_id"));
				userInformation.setUserName(rs.getString("username"));
				userInformation.setEmail(rs.getString("email"));
				userInformation.setDob(rs.getDate("dob").toLocalDate());
				userInformation.setPhnNo(rs.getLong("phn_no"));
				userInformation.setPassword(rs.getString("password"));
				userInformation.setAddress(rs.getString("address"));
				userInformation.setUserType(rs.getString("user_type"));
			}
		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pst.close();
			rs.close();
		}

		return userInformation;
	}

	@Override
	public UserInformation retrieveUserInfoUsingUserId(String userid) throws SQLException {

		UserInformation userInformation = new UserInformation();
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			String query = "select * from user_information where user_id=?";

			pst = con.prepareStatement(query);
			pst.setString(1, userid);
			rs = pst.executeQuery();

			if (rs.next()) {

				userInformation.setUserId(rs.getString("user_id"));
				userInformation.setUserName(rs.getString("username"));
				userInformation.setEmail(rs.getString("email"));
				userInformation.setDob(rs.getDate("dob").toLocalDate());
				userInformation.setPhnNo(rs.getLong("phn_no"));
				userInformation.setPassword(rs.getString("password"));
				userInformation.setAddress(rs.getString("address"));
				userInformation.setUserType(rs.getString("user_type"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			rs.close();
			pst.close();
		}

		return userInformation;
	}

	@Override
	public int updateAddressUsingEmail(String email, String address) {
		int i = 0;
		try {
			String query = "update user_information set address=? where user_id=?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, address);
			pst.setString(2, email);
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;

	}

	@Override
	public int updateEmailUsingUserId(String userid, String email) {
		int i = 0;
		try {
			String query = "update user_information set email=? where user_id=?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, email);
			pst.setString(2, userid);
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;

	}

	@Override
	public UserInformation retrieveUserInfoUsingUserName(String username) throws SQLException {

		UserInformation userInformation = new UserInformation();
		PreparedStatement pst = null;
		ResultSet rs = null;

		String query = "select * from user_information where username=?";
		try {
			pst = con.prepareStatement(query);
			pst.setString(1, username);
			rs = pst.executeQuery();

			if (rs.next()) {

				userInformation.setUserId(rs.getString("user_id"));
				userInformation.setUserName(rs.getString("username"));
				userInformation.setEmail(rs.getString("email"));
				userInformation.setDob(rs.getDate("dob").toLocalDate());
				userInformation.setPhnNo(rs.getLong("phn_no"));
				userInformation.setPassword(rs.getString("password"));
				userInformation.setAddress(rs.getString("address"));
				userInformation.setUserType(rs.getString("user_type"));
			}
		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			pst.close();
			rs.close();
		}

		return userInformation;
	}

	@Override
	public int updatePhoneNumberUsingEmail(String id, long number) {
		int i = 0;
		try {
			String query = "update user_information set phn_no=? where user_id=?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setLong(1, number);
			pst.setString(2, id);
			i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public int updatePasswordUsingId(String id, String password) {
		
	int i = 0;
	try {
			String query = "update user_information set password=? where user_id=?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, password);
			pst.setString(2, id);
		i = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;

	}


}