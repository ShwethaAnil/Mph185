package com.mphasis.bo;

import java.sql.SQLException;
import java.util.List;

import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.PassengerDetails;

public interface PassengerDetailsBo {

	public List<PassengerDetails> getPassenger() throws BusinessException;
	public void addPassenger(PassengerDetails p) throws BusinessException;
	public PassengerDetails retrievePassengerById(String passengerid) throws BusinessException, SQLException;
	public void editPassengerById(String passengerid, int age) throws BusinessException;
	public void removePassenger(String passengerid) throws BusinessException;
	

}
