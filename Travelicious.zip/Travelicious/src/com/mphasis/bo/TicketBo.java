package com.mphasis.bo;

import java.sql.SQLException;
import java.util.List;

import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.Ticket;

public interface TicketBo {
	
	public List<Ticket> getTickets() throws BusinessException;
	public void addTicket(Ticket t) throws BusinessException, SQLException;
	public Ticket retrieveTicketById(String ticketid) throws BusinessException, SQLException;
	public void editStatusByTicketId(String ticketid, String status) throws BusinessException;
	public void editCostByTicketId(String ticketid, double cost,String deptdate, String fclass) throws BusinessException, SQLException;
	public void removeTicket(String ticketid) throws BusinessException;

}
