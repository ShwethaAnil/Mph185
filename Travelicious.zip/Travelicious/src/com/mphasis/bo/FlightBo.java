package com.mphasis.bo;

import java.sql.SQLException;
import java.util.List;

import com.mphasis.dto.SearchFlightDetails;
import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.Flight;



public interface FlightBo {
	

	public List<Flight> getFlights()throws BusinessException;
	public Flight getFlightById(String flightId)throws BusinessException,SQLException;
	public void addFlight(Flight f) throws BusinessException;
	public void updateSeatsByFlightId(String flightId, int numOfSeats)throws BusinessException;
	public void updateFareByFlightId(String flightId, double minFare)throws BusinessException;	
	public void updateClassByFlightId(String flightId, String typeOfClass,double minFare)throws BusinessException;
	public void removeFlight(String flightId)throws BusinessException;
	public List<SearchFlightDetails> getSearchDetails(String source,String destination,String deptdate)throws BusinessException,SQLException;
	void sortByFare(List<SearchFlightDetails> sfs) throws BusinessException;
}
