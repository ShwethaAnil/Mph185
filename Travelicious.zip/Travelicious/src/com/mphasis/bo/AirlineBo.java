package com.mphasis.bo;

import java.sql.SQLException;
import java.util.List;

import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.Airline;

public interface AirlineBo {
	public List<Airline> getAirline()throws BusinessException;
	public Airline getAirlineById(String airlineid)throws BusinessException, SQLException;
	public void addAirline(Airline a) throws BusinessException;
	public void editAirline(String airlineid, String airlineName)throws BusinessException;
	public void removeAirline(String airlineid)throws BusinessException;

}
