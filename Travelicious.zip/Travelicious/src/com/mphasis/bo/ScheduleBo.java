package com.mphasis.bo;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.Schedule;

public interface ScheduleBo {
	 public void editSchedule( String scheduleId, LocalDate deptDate, LocalDate arrDate, LocalTime deptTime, LocalTime arrTime, String flightId)throws BusinessException, SQLException;
	 public void removeSchedule(String scheduleId)throws BusinessException;
	 public Schedule getScheduleById(String scheduleId) throws BusinessException, SQLException;
	 public void addSchedule(Schedule s)throws BusinessException, SQLException;
	 public List<Schedule> getSchedules() throws BusinessException,SQLException;
	 public Schedule getScheduleByDept(String depDate)throws BusinessException, SQLException;
	void editScheduleTime(String scheduleId, LocalTime deptTime,LocalTime arrTime)
			throws BusinessException, SQLException;
}
