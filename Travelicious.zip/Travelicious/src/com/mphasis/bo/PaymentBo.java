package com.mphasis.bo;

import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.Payment;

public interface PaymentBo {
	public int checkDetails(Payment p) throws BusinessException;

}
