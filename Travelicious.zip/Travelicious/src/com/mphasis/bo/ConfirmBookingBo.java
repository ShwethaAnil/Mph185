package com.mphasis.bo;

import java.sql.SQLException;
import java.util.List;

import com.mphasis.dto.ConfirmBooking;
import com.mphasis.exception.BusinessException;

public interface ConfirmBookingBo {

	public List<ConfirmBooking> getBookings(String userid)throws BusinessException, SQLException;
	public void sortByDate(List<ConfirmBooking> cfs) throws BusinessException;
}
