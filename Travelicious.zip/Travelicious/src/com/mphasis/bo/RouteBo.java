package com.mphasis.bo;

import java.sql.SQLException;
import java.util.List;

import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.Route;

public interface RouteBo {

	 public void addRoute(Route r) throws BusinessException, SQLException;
	 public void editRoute(String routeId, String source, String destination, String scheduleId)throws BusinessException;
	 public void removeRoute(String routeId)throws BusinessException;
	 public Route getRouteById(String routeId) throws BusinessException, SQLException;
	 public List<Route> getRoutes() throws BusinessException, SQLException;
	 public Route getRouteBySourceDest(String source, String destination)throws BusinessException, SQLException;
}
