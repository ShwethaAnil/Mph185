package com.mphasis.bo;

import java.sql.SQLException;
import java.util.List;

import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.Airport;

public interface AirportBo {
	public List<Airport> getAirport()throws BusinessException;
	public Airport getAirportById(String airortid)throws BusinessException, SQLException;
	public void addAirport(Airport a) throws BusinessException;
	
	public void removeAirline(String airportid)throws BusinessException;
	public void editAirport(String airportid, String airportName, String airlineid) throws BusinessException;

}
