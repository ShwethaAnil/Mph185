package com.mphasis.bo;

import java.sql.SQLException;

import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.UserInformation;

public interface UserInfoBao {
	public UserInformation login(String username, String password) throws SQLException, BusinessException;

	public int changePassword(String email, String password) throws SQLException, BusinessException;

	public int changeAddress(String email, String address) throws SQLException,BusinessException;

	public int changeEmail(String userid, String newemail) throws SQLException, BusinessException;
	
	public int changePhoneNumber(String email, long number) throws SQLException, BusinessException;

	int registerCustomer(UserInformation userInformation) throws BusinessException, SQLException;

	UserInformation checkEmail(String email) throws SQLException,BusinessException;

	UserInformation forgotPassword(String email) throws SQLException, BusinessException;
	

}
