package com.mphasis.dto;

import java.time.LocalDate;
import java.time.LocalTime;

public class SearchFlightDetails {
	
	private String airlinename;
	private String flightid;
	private LocalDate deptdate;
	private LocalDate arrdate;
	private LocalTime depttime;
	private LocalTime arrtime;
	private String source;
	private String destination;
	private double minfare;
	
	
	public SearchFlightDetails() {
		super();
	}
	public SearchFlightDetails(String airlinename, String flightid, LocalDate deptdate, LocalDate arrdate,
			LocalTime depttime, LocalTime arrtime, String source, String destination, double minfare) {
		super();
		this.airlinename = airlinename;
		this.flightid = flightid;
		this.deptdate = deptdate;
		this.arrdate = arrdate;
		this.depttime = depttime;
		this.arrtime = arrtime;
		this.source = source;
		this.destination = destination;
		this.minfare = minfare;
	}
	public String getAirlinename() {
		return airlinename;
	}
	public void setAirlinename(String airlinename) {
		this.airlinename = airlinename;
	}
	public String getFlightid() {
		return flightid;
	}
	public void setFlightid(String flightid) {
		this.flightid = flightid;
	}
	public LocalDate getDeptdate() {
		return deptdate;
	}
	public void setDeptdate(LocalDate deptdate) {
		this.deptdate = deptdate;
	}
	public LocalDate getArrdate() {
		return arrdate;
	}
	public void setArrdate(LocalDate arrdate) {
		this.arrdate = arrdate;
	}
	public LocalTime getDepttime() {
		return depttime;
	}
	public void setDepttime(LocalTime depttime) {
		this.depttime = depttime;
	}
	public LocalTime getArrtime() {
		return arrtime;
	}
	public void setArrtime(LocalTime arrtime) {
		this.arrtime = arrtime;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public double getMinfare() {
		return minfare;
	}
	public void setMinfare(double minfare) {
		this.minfare = minfare;
	}
	@Override
	public String toString() {
		
		return "\n-----------------------------------------------------------------------\n"
				+ "Airlinename : " + airlinename + 
				"\nFlightid : " +flightid +
				"\nDeptdate : " + deptdate+ 
				"\nArrdate : " + arrdate + 
				"\nDepttime : " + depttime +
				"\nArrtime : " + arrtime + 
				"\nSource : " + source+ 
				"\nDestination : " + destination + 
				"\nMinfare : " + minfare + "\n-----------------------------------------------------------------------\n\n";
	}
	
	

}
