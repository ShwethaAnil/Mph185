package com.mphasis.dto;

import java.time.LocalDate;

public class ConfirmBooking {
   public ConfirmBooking(String airlinename, String flightid, String ticketid, String source, String destination, LocalDate deptdate,
			String passengername, int age, String gender, String passportnumber,String status, String userId) {
		super();
		this.airlinename = airlinename;
		this.flightid =flightid;
		this.setTicketid(ticketid);
		this.source = source;
		this.destination = destination;
		this.deptdate = deptdate;
		this.passengername = passengername;
		this.age = age;
		this.gender = gender;
		this.passportnumber = passportnumber;
		this.status=status;
		this.userId = userId;
	}
public ConfirmBooking() {
	// TODO Auto-generated constructor stub
}
private String airlinename;
private String flightid;
private String ticketid;
   private String source;
   private String destination;
   private LocalDate deptdate;
   private String passengername;
   private int age;
	private String gender;
	private String passportnumber;
	private String status;
	private String userId;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAirlinename() {
		return airlinename;
	}
	public void setAirlinename(String airlinename) {
		this.airlinename = airlinename;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public LocalDate getDeptdate() {
		return deptdate;
	}
	public void setDeptdate(LocalDate deptdate) {
		this.deptdate = deptdate;
	}
	public String getPassengername() {
		return passengername;
	}
	public void setPassengername(String passengername) {
		this.passengername = passengername;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPassportnumber() {
		return passportnumber;
	}
	public void setPassportnumber(String passportnumber) {
		this.passportnumber = passportnumber;
	}
	public String getUserid() {
		return userId;
	}
	public void setUserid(String userId) {
		this.userId = userId;
	}
	public String getFlightid() {
		return flightid;
	}
	public void setFlightid(String flightid) {
		this.flightid = flightid;
	}
	public String getTicketid() {
		return ticketid;
	}
	public void setTicketid(String ticketid) {
		this.ticketid = ticketid;
	}
	@Override
	public String toString() {
		return "Booking Details: \n---------------------------------------------------------------------------\n"
				+ "airlinename : " + airlinename + "\nflightid : " +flightid + "\nticketid : " +ticketid+ "\nsource : " + source
				+ "\ndestination : " + destination + "\ndeptdate : " + deptdate + "\npassengername : " + passengername
				+ "\nage : " + age + "\ngender : " + gender + "\npassportnumber : " + passportnumber + "\nstatus : " +status 
				+ "\n---------------------------------------------------------------------------\n";
	}
   
}
