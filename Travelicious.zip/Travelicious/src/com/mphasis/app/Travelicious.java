package com.mphasis.app;

import java.sql.SQLException;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.List;
import java.util.Scanner;

import com.mphasis.bo.ConfirmBookingBo;
import com.mphasis.bo.FlightBo;
import com.mphasis.boimpl.ConfirmBookingBoImpl;
import com.mphasis.boimpl.FlightBoImpl;
import com.mphasis.bo.PassengerDetailsBo;
import com.mphasis.boimpl.PassengerDetailsBoImpl;
import com.mphasis.bo.PaymentBo;
import com.mphasis.boimpl.PaymentBoImpl;
import com.mphasis.bo.RouteBo;
import com.mphasis.boimpl.RouteBoImpl;
import com.mphasis.bo.ScheduleBo;
import com.mphasis.boimpl.ScheduleBoImpl;
import com.mphasis.bo.TicketBo;
import com.mphasis.boimpl.TicketBoImpl;
import com.mphasis.bo.UserInfoBao;
import com.mphasis.boimpl.UserInfoBaoImpl;
import com.mphasis.dto.ConfirmBooking;
import com.mphasis.dto.SearchFlightDetails;
import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.Flight;
import com.mphasis.pojos.PassengerDetails;
import com.mphasis.pojos.Payment;
import com.mphasis.pojos.Route;
import com.mphasis.pojos.Schedule;
import com.mphasis.pojos.Ticket;
import com.mphasis.pojos.UserInformation;;;

public class Travelicious {

	private static Scanner sc;

	public static void main(String[] args) throws SQLException {
		sc = new Scanner(System.in);
		List<SearchFlightDetails> sfs = null;
		TicketBo ticketBo = new TicketBoImpl();
		UserInfoBao userInfoBao = new UserInfoBaoImpl();
		UserInformation userInformation = new UserInformation();
		FlightBo flightBo = new FlightBoImpl();
		ScheduleBo scheduleBo = new ScheduleBoImpl();
		PassengerDetailsBo passengerDetailsBo = new PassengerDetailsBoImpl();
		PaymentBo paymentBo = new PaymentBoImpl();
		RouteBo routeBo = new RouteBoImpl();
		ConfirmBookingBo bookingsBo = new ConfirmBookingBoImpl();
		int goThere;
		String source = "";
		String dest = null, date = null;
		Flight f;
		System.out.println("**Welcome to Travelicious**");
		main: do {
			System.out.println(" 1.Login \n 2.Register\n 3.Search Flight\n 4.Forgot Password\n 5.Exit");
			goThere = sc.nextInt();
			switch (goThere) {
			case 1:
				try {
					System.out.println("Enter username");
					String username = sc.next();
					System.out.println("Enter password");
					String pass = sc.next();
					userInformation = userInfoBao.login(username, pass);
					System.out.println("Login Successful");
					if (userInformation.getUserType().equalsIgnoreCase("user")) {
						user: do {
							System.out.println(
									" 1.Update PhoneNumber\n 2.Update Email\n 3.Update Password\n 4.Update Address\n 5.Search Flight\n 6.My bookings \n 7.Logout\n Enter your choice:");
							int choice = sc.nextInt();
							if (choice == 1) {
								try {
									System.out.println("Enter new PhoneNumber:");
									int i = userInfoBao.changePhoneNumber(userInformation.getEmail(), sc.nextLong());
									if (i == 1) {
										System.out.println("Phone number updated succesfully");
										continue user;
									} else {
										System.out.println("Not updated.");
									}
								} catch (BusinessException e) {
									System.out.println(e.getMessage());
								}
							} else if (choice == 2) {
								try {
									System.out.println("enter new email id:");
									int i = userInfoBao.changeEmail(userInformation.getUserId(), sc.next());
									if (i == 1) {
										System.out.println("Email updated succesfully");
										continue user;
									} else {
										System.out.println("Not updated.");
									}
								} catch (BusinessException e) {
									System.out.println(e.getMessage());
								}
							} else if (choice == 3) {
								try {
									System.out.println("Enter new Password");
									String password = sc.next();
									int i = userInfoBao.changePassword(userInformation.getUserId(), password);
									if (i == 1) {
										System.out.println("Password updated succesfully");
										continue user;
									} else {
										System.out.println("Not updated.");
									}

								} catch (BusinessException e) {
									System.out.println(e.getMessage());
								}

							} else if (choice == 4) {
								try {
									System.out.println("Enter new address");
									String add = sc.next();
									int i = userInfoBao.changeAddress(userInformation.getUserId(), add);

									if (i == 1) {
										System.out.println("Address updated succesfully");
										continue user;
									} else {
										System.out.println("Not updated.");
									}
								} catch (BusinessException e) {
									System.out.println(e.getMessage());
								}
							} else if (choice == 5) {
								if (source.equals("")) {
									System.out.println(
											"Enter your choice\n 1.Search By Source, Destination and Date\n 2.Search By Source and Destination");
									int searchChoice = sc.nextInt();
									if (searchChoice == 1) {
										System.out.println("Enter Source");
										source = sc.next();
										System.out.println("Enter Destination");
										dest = sc.next();
										System.out.println("Enter Travalling Date");
										date = sc.next();

										try {
											sfs = flightBo.getSearchDetails(source, dest, date);
											// sfs.forEach(sn -> System.out.println(sn));
											//flightBo.sortByFare(sfs);
										} catch (BusinessException | NullPointerException e) {

											System.out.println(e.getMessage());
											break;
										}
									} else if (searchChoice == 2) {
										System.out.println("Enter the source");
										source = sc.next();
										System.out.println("Enter the destination");
										dest = sc.next();

										try {
											LocalDate today = LocalDate.now();
											date = today.toString();
											System.out.println();
											sfs = flightBo.getSearchDetails(source, dest, date);
											// sfs.forEach(sn -> System.out.println(sn));
											// flightBo.sortByFare(sfs);
										} catch (BusinessException | NullPointerException e) {

											System.out.println(e.getMessage());
											break;
										}
									}
								}
								System.out.println("Search Flight Details:");
								flightBo.sortByFare(sfs);
								System.out.println("Book Flight by Id");
								f = null;
								try {
									f = flightBo.getFlightById(sc.next());
								} catch (BusinessException e) {
									System.out.println(e.getMessage());
									break;
								}
								if (userInformation.getUserId() == null) {
									goThere = 1;
									System.out.println("Login First!");
									break;
								}

								System.out.println("Enter number of passengers:");
								int noPassenger = sc.nextInt();
								for (int i = 1; i <= noPassenger; i++) {
									System.out.println("");
									System.out.println("Enter Passenger Name:");
									String name = sc.next();
									System.out.println("Enter Passenger Age:");
									int age = sc.nextInt();
									System.out.println("Enter Gender:");
									System.out.println("Select Gender\n 1.Female\n 2.Male\n 3.Others\n");
									int gen = sc.nextInt();
									String gender = null;
									if (gen == 1) {
										gender = "Female";
									} else if (gen == 2) {
										gender = "Male";
									} else if (gen == 3) {
										gender = "Others";
									} else {
										System.out.println("Invalid choice!");
									}
									System.out.println("Enter Passport Number:");
									String passport = sc.next();
									PassengerDetails p = new PassengerDetails(name, age, gender, passport,
											userInformation.getUserId());

									try {
										passengerDetailsBo.addPassenger(p);
										Ticket t = new Ticket(p.getPassengerid(), f.getFlightId(), f.getMinFare());
										ticketBo.addTicket(t);
										ticketBo.editCostByTicketId(t.getTicketid(), f.getMinFare(), date,f.getTypeOfClass());
										System.out.println("Passenger Added ! Passenger ID is : " + p.getPassengerid());
										if (noPassenger > 1) {
											System.out.println("\nAdd Details for next Passenger:");
										}
									} catch (BusinessException e) {
										System.out.println(e.getMessage());
									}
								}

								if (noPassenger > 0) {
									System.out.println("Enter Payment Details");
									System.out.println("Enter the card type");
									String cardType=sc.next();
									System.out.println("Enter the card number");
									long cardNum=sc.nextLong();
									System.out.println("Enter the expiry date");
									YearMonth expiryDate= YearMonth.parse(sc.next());
									System.out.println("Enter the CVV");
									int cvv=sc.nextInt();
									System.out.println("Enter the card holder name");
									String hName=sc.next();
									Payment pay = new Payment(cardType,cardNum,expiryDate,cvv,hName);
									int success;
									try {
										success = paymentBo.checkDetails(pay);
										if (success == 1) {
											System.out.println("Payment is Successfull");
											System.out.println(" 1.View Booking\n 2.logout\n Enter user Choice:");
											int ch = sc.nextInt();

											if (ch == 1) {
												List<ConfirmBooking> con = null;

												try {
													con = bookingsBo.getBookings(userInformation.getUserId());
													// con.forEach(cn -> System.out.println(cn));
													bookingsBo.sortByDate(con);
													System.out.println("1.Cancel Booking");
													int can = sc.nextInt();
													if (can == 1) {
														System.out.println("Enter the ticket id you want to cancel");
														String ticketid = sc.next();
														ticketBo.editStatusByTicketId(ticketid, "Cancelled");
														System.out.println("Ticket cancelled");
													}
												} catch (BusinessException e) {
													System.out.println(e.getMessage());
												}

											} else if (ch == 2) {
												continue main;
											}

										} else {
											System.out.println("Payment Failed");
										}
									} catch (BusinessException e) {
										System.out.println(e.getMessage());
									}

								}
							} else if (choice == 6) {
								List<ConfirmBooking> con = null;
								try {
									con = bookingsBo.getBookings(userInformation.getUserId());
									// con.forEach(cn -> System.out.println(cn));
									bookingsBo.sortByDate(con);
									System.out.println(" 1.Cancel Booking\n 2.Back\n Enter your Choice\n");
									int can = sc.nextInt();
									if (can == 1) {
										System.out.println("Enter the ticket id you want to cancel");
										String ticketid = sc.next();
										ticketBo.editStatusByTicketId(ticketid, "Cancelled");
										System.out.println("Ticket cancelled");
									} else if (can == 2) {
										continue user;
									}
								} catch (BusinessException e) {
									System.out.println(e.getMessage());
								}
							} else if (choice == 7) {
								continue main;
							}

						} while (true);
					} else {
						System.out.println("Welcome "+userInformation.getUserName());
						admin: do {
							System.out.println(
									"Enter Your Choice\n 1.View Passenger\n 2.Manage Flight\n 3.Manage Schedule\n 4.Manage Route\n 5.Exit");
							int adminChoice = sc.nextInt();
							if (adminChoice == 1) {
								do {
									System.out.println("Enter Your Choice\n 1.View Passenger\n 2.Back\n");
									int choice1 = sc.nextInt();
									switch (choice1) {
									case 1:
										List<PassengerDetails> passengers;
										passengers = passengerDetailsBo.getPassenger();
										passengers.forEach(ps -> System.out.println(ps));
										break;
									case 2:
										continue admin;
									default:
										System.out.println("Invalid Choice");
									}
								} while (true);
							} else if (adminChoice == 2) {
								do {
									System.out.println(" Manage Flight\n 1. Add Flight" + " \n 2. Retrieve Flight by Flight ID "
											+ "\n 3. Retrieve all flights " + "\n 4. Update data of flight"
											+ " \n 5.Delete Flight\n 6.Back\n");
									switch (sc.nextInt()) {
									case 1:

										System.out.println("Enter the Flight details");
							            System.out.println("enter the flight id");
										String flightid=sc.next();
										System.out.println("enter the number of seats");
										int ns=sc.nextInt();
										System.out.println("enter the type of class");
										String fclass=sc.next();
										System.out.println("enter the minimum fare");
										double fare=sc.nextDouble();
										System.out.println("enter the airlineid");
										String airlineid=sc.next();
										Flight flight = new Flight(flightid, ns, fclass, fare,airlineid);
										try {
											flightBo.addFlight(flight);
											System.out.println("Flight added successfully");
										} catch (BusinessException e) {
											System.out.println(e.getMessage());
										}
										break;
									case 2:
										System.out.println("Enter the FlightId : F123");
										try {
											Flight fl = flightBo.getFlightById(sc.next());
											System.out.println("FlightDetails:");
											System.out.println(fl);
											
										} catch (BusinessException | SQLException e) {
											System.out.println(e.getMessage());

										}
										break;
									case 3:
										System.out.println("List of flights");
										List<Flight> flights;
										try {
											flights = flightBo.getFlights();
											System.out.println("FlightDetails:");
											flights.forEach(fn -> System.out.println(fn));
										} catch (BusinessException e1) {
											System.out.println(e1.getMessage());
										}

										break;
									case 4:
										System.out.println("Enter the flightid for which you want to update");
										String id = sc.next();
										System.out.println(
												"Choose the field u want to update 1.number of seats 2.Fare 3.class");
										int choice = sc.nextInt();
										if (choice == 1) {
											try {
												System.out.println("Enter the number of seats");
												flightBo.updateSeatsByFlightId(id, sc.nextInt());
												System.out.println("Data updated successfully");

											} catch (BusinessException e) {
												System.out.println(e.getMessage());
											}
										} else if (choice == 2) {
											try {
												System.out.println("Enter the fare");
												flightBo.updateFareByFlightId(id, sc.nextDouble());
												System.out.println("Data updated successfully");
											} catch (BusinessException e) {
												System.out.println(e.getMessage());
											}

										} else if (choice == 3) {
											try {
												System.out.println("Enter the type of class and fare");
												flightBo.updateClassByFlightId(id, sc.next(), sc.nextDouble());
												System.out.println("Data updated successfully");
											} catch (BusinessException e) {
												System.out.println(e.getMessage());
											}
										} else {
											System.out.println("invalid choice");
										}

										break;
									case 5:
										System.out.println("Enter flight Id which you want to delete");
										try {
											flightBo.removeFlight(sc.next());
											System.out.println("Flight deleted successfully");
										} catch (BusinessException e) {
											System.out.println(e.getMessage());
										}
										break;
									case 6:
										continue admin;
									default:
										System.out.println("Invalid choice");

									}

								} while (true);
							} else if (adminChoice == 3) {
								do {
									System.out.println("Manage Schedule"+" \n 1. Add Schedule" + " \n 2. Retrieve Schedule by Schedule ID "
											+ "\n 3. Retrieve all Schedules " + "\n 4. Update Schedule"
											+ " \n 5.Delete Schedule\n 6.back");
									switch (sc.nextInt()) {
									case 1:
										System.out.println("Enter the Scheduleid :");
										String scheduleid = sc.next();
										System.out.println("Enter Departure date:");
										String deptdate = sc.next();
										System.out.println("Enter Arrival date:");
										String arrdate = sc.next();
										System.out.println("Enter Departure Time:");
										String depttime = sc.next();
										System.out.println("Enter Arrival Time:");
										String arrtime = sc.next();
										System.out.println("Enter Flight ID:");
										String flightid1 = sc.next();
										Schedule s = new Schedule(scheduleid, LocalDate.parse(deptdate),
												LocalDate.parse(arrdate), LocalTime.parse(depttime),
												LocalTime.parse(arrtime), flightid1);
										try {
											scheduleBo.addSchedule(s);
											System.out.println("Schedule is added");
										} catch (BusinessException e) {
											System.out.println(e.getMessage());
										}
										break;
									case 2:
										System.out.println("Enter the Schedule ID which you want to retrieve");
										try {
											Schedule schedule;

											schedule = scheduleBo.getScheduleById(sc.next());
											System.out.println("SheduleDetails:");
											System.out.println(schedule);
										} catch (BusinessException | SQLException e) {

											System.out.println(e.getMessage());
										}
										break;
									case 3:
										List<Schedule> schedules;
										try {
											schedules = scheduleBo.getSchedules();
											System.out.println("SheduleDetails:");
											schedules.forEach(pn -> System.out.println(pn));
										} catch (BusinessException e1) {
											System.out.println(e1.getMessage());
										}

										break;
									case 4:
										System.out.println(
												"Enter your Choice\n 1.Update all the Details\n 2.Update Timings");
										int update = sc.nextInt();
										if (update == 1) {
											System.out.println("Enter the scheduleid which you want to update:");
											String scheduleid1 = sc.next();
											System.out.println("Enter Departure date:");
											String udeptdate = sc.next();
											System.out.println("Enter Arrival date:");
											String uarrdate = sc.next();
											System.out.println("Enter Departure Time:");
											String udepttime = sc.next();
											System.out.println("Enter Arrival Time:");
											String uarrtime = sc.next();
											System.out.println("Enter Flight ID:");
											String uflightid = sc.next();
											try {
												scheduleBo.editSchedule(scheduleid1, LocalDate.parse(udeptdate),
														LocalDate.parse(uarrdate), LocalTime.parse(udepttime),
														LocalTime.parse(uarrtime), uflightid);
												System.out.println("Schedule is updated");
											} catch (BusinessException e) {
												System.out.println(e.getMessage());
											}
										} else if (update == 2) {
											System.out.println("Enter the scheduleid which you want to update: ");
											String scid = sc.next();
											System.out.println("Enter Departure Time:");
											String updepttime = sc.next();
											System.out.println("Enter Arrival Time:");
											String uparrtime = sc.next();
											try {
												scheduleBo.editScheduleTime(scid, LocalTime.parse(updepttime),
														LocalTime.parse(uparrtime));
												System.out.println("Schedule is updated");
											} catch (BusinessException e) {
												System.out.println(e.getMessage());
											}
										} else {
											break;
										}
										break;
									case 5:
										System.out.println("Enter the scheduleid which you want to remove");
										try {
											scheduleBo.removeSchedule(sc.next());
											System.out.println("Schedule is deleted\n");
										} catch (BusinessException e) {
											System.out.println(e.getMessage());
										}
										break;
									case 6:
										continue admin;
									default:
										System.out.println("Invalid choice");
									}

								} while (true);
							} else if (adminChoice == 4) {
								do {
									System.out.println("Manage Route"+"\n 1. Add Route" + " \n 2. Retrieve Route by Route ID "
											+ "\n 3. Retrieve all Routes " + "\n 4. Update Routes"
											+ " \n 5.Delete Routes\n 6.Back\n");
									switch (sc.nextInt()) {
									case 1:

										System.out.println("Enter the route details");
							            System.out.println("enter the route id");
										String routeid=sc.next();
										System.out.println("enter the source");
										String asource =sc.next();
										System.out.println("enter the destination");
										String adest=sc.next();
										System.out.println("enter the schedule id");
										String scheduleid=sc.next();		
										Route r = new Route(routeid,asource, adest,scheduleid);

										try {
											routeBo.addRoute(r);
											System.out.println("Route is added");
										} catch (BusinessException e) {
											System.out.println(e.getMessage());
										}
										break;
									case 2:
										System.out.println("Enter the Route ID which you want to retrieve");
										try {
											Route route;
											route = routeBo.getRouteById(sc.next());
											System.out.println("RouteDetails:");
											System.out.println(route);
										} catch (BusinessException | SQLException e) {

											System.out.println(e.getMessage());
										}
										break;
									case 3:
										List<Route> routes;
										try {
											routes = routeBo.getRoutes();
											System.out.println("RouteDetails:");
											routes.forEach(pn -> System.out.println(pn));
										} catch (BusinessException e1) {

											System.out.println(e1.getMessage());
										}

										break;
									case 4:
										System.out.println("Update all Route Details");
										try {
											System.out.println("enter the route id");
											String rid=sc.next();
											System.out.println("enter the source");
											String usource=sc.next();
											System.out.println("enter the destination");
											String udest=sc.next();
											System.out.println("enter the scheduleid");
											String usid=sc.next();
											routeBo.editRoute(rid,usource,udest,usid);
											System.out.println("route updated");
										} catch (BusinessException e) {
											System.out.println(e.getMessage());
										}

										break;
									case 5:
										System.out.println("Enter routeid which you want to delete");
										try {
											routeBo.removeRoute(sc.next());
											System.out.println("Route deleted");
										} catch (BusinessException e) {
											System.out.println(e.getMessage());
										}
										break;
									case 6:
										continue admin;
									default:
										System.out.println("Invalid choice");
									}

								} while (true);
							} else if (adminChoice == 5) {
								System.out.println("Thank you");
								System.exit(0);
								sc.close();

							}

						} while (true);
					}
				} catch (SQLException | BusinessException e) {
					System.out.println(e.getMessage());
				}

				break;
			case 2:
				System.out.print("Enter Username");
				String uname=sc.next();
				System.out.print("Enter Email");
				String mail= sc.next();
				System.out.print("Enter Date of Birth");
				String dob= sc.next();
				System.out.print("Enter Phone Number");
				long phn= sc.nextLong();
				System.out.print("Enter Address");
				String address= sc.next();
				System.out.print("Enter Password");
				String pass= sc.next();
				userInformation = new UserInformation(uname, mail, LocalDate.parse(dob), phn,
						address, pass);
				try {
					userInfoBao.registerCustomer(userInformation);
					System.out.println("Registration Successful! login first");
					continue;
				} catch (BusinessException e) {
					System.out.println(e.getMessage());
				}
				break;

			case 3:
				System.out.println(
						"enter your choice\n 1.SearchBy Source, Destination and Date\n 2.Search By Source and Destination");
				int searchChoice = sc.nextInt();
				if (searchChoice == 1) {
					System.out.println("Enter Source");
					source = sc.next();
					System.out.println("Enter Destination");
					dest = sc.next();
					System.out.println("Enter Travalling Date");
					date = sc.next();

					try {
						sfs = flightBo.getSearchDetails(source, dest, date);
						// sfs.forEach(sn -> System.out.println(sn));
						System.out.println("Search Flight Details:");
						flightBo.sortByFare(sfs);
					} catch (BusinessException | NullPointerException e) {
						System.out.println(e.getMessage());
						break;
					}
				} else if (searchChoice == 2) {
					System.out.println("enter the source");
					source = sc.next();
					System.out.println("enter the destination");
					dest = sc.next();

					try {
						LocalDate today = LocalDate.now();
						date = today.toString();
						System.out.println();
						sfs = flightBo.getSearchDetails(source, dest, date);
						// sfs.forEach(sn -> System.out.println(sn));
						System.out.println("Search Flight Details:");
						flightBo.sortByFare(sfs);
					} catch (BusinessException | NullPointerException e) {

						System.out.println(e.getMessage());
						break;
					}
				}

				System.out.println("Book Flight by Id");
				f = null;
				try {
					f = flightBo.getFlightById(sc.next());
				} catch (BusinessException e) {
					System.out.println(e.getMessage());
				}
				if (userInformation.getUserId() == null) {
					goThere = 1;
					System.out.println("Login First!");
					break;
				}
				break;
			case 4:
				UserInformation userInfo = null;
				System.out.println("Enter your Email Id");
				String email = sc.next();

				try {
					userInfo = userInfoBao.forgotPassword(email);
					if(userInfo.getEmail()!=null) {
						System.out.println("Enter the new password");
						String cpassword=sc.next();
						System.out.println("Enter the confirm password");
						String confirmPassword=sc.next();
						if(cpassword.equals(confirmPassword)) {
							int i = userInfoBao.changePassword(userInfo.getUserId(), cpassword);
							if (i == 1) {
								System.out.println("Password updated succesfully");
								continue main;
							} else {
								System.out.println("Not updated.");
								continue main;
							}
							
						}
						else {
							System.out.println("Password is not matching");
						}
						
					}

				} catch (BusinessException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 5:
				System.out.println("Thank you");
				System.exit(0);
				sc.close();
			default:
				System.out.println("Invalid Choice");
			}
		} while (true);
	}
}