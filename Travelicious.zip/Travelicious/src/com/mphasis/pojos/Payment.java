package com.mphasis.pojos;


import java.time.YearMonth;

public class Payment {
	private String cardType;
	private long cardNum;
	private YearMonth expiryDate;
	private int cvv;
	private String holderName;
	
	
	public Payment() {
		super();
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public long getCardNum() {
		return cardNum;
	}
	public void setCardNum(long cardNum) {
		this.cardNum = cardNum;
	}
	public YearMonth getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(YearMonth expiryDate) {
		this.expiryDate = expiryDate;
	}
	public int getCvv() {
		return cvv;
	}
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}
	public Payment(String cardType, long cardNum, YearMonth expiryDate, int string, String holderName) {
		super();
		this.cardType = cardType;
		this.cardNum = cardNum;
		this.expiryDate = expiryDate;
		this.cvv = string;
		this.holderName = holderName;
	}
	@Override
	public String toString() {
		return "Payment [cardType=" + cardType + ", cardNum=" + cardNum + ", expiryDate=" + expiryDate + ", cvv=" + cvv
				+ ", holderName=" + holderName + "]";
	}
	

}
