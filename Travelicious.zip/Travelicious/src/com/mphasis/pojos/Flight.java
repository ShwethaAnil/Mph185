package com.mphasis.pojos;

public class Flight {
	
   private	String flightId;
   private int numOfSeats;
   private String typeOfClass;
   private double minFare;
   private String airlineId;
   
   

public Flight() {
	super();
}
public Flight(String flightId, int numOfSeats, String typeOfClass, double minFare, String airlineId) {
	super();
	this.flightId = flightId;
	this.numOfSeats = numOfSeats;
	this.typeOfClass = typeOfClass;
	this.minFare = minFare;
	this.airlineId = airlineId;
}
public String getFlightId() {
	return flightId;
}
public void setFlightId(String flightId) {
	this.flightId = flightId;
}
public int getNumOfSeats() {
	return numOfSeats;
}
public void setNumOfSeats(int numOfSeats) {
	this.numOfSeats = numOfSeats;
}
public String getTypeOfClass() {
	return typeOfClass;
}
public void setTypeOfClass(String typeOfClass) {
	this.typeOfClass = typeOfClass;
}
public double getMinFare() {
	return minFare;
}
public void setMinFare(double minFare) {
	this.minFare = minFare;
}
public String getAirlineId() {
	return airlineId;
}
public void setAirlineId(String airlineId) {
	this.airlineId = airlineId;
}

@Override
public String toString() {
	return ""
			+ " \n--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n"
			+ "flightId : " + flightId + "\nnumOfSeats : " + numOfSeats + "\ntypeOfClass : " + typeOfClass + "\nminFare : "
			+ minFare + "\nairlineId : " + airlineId + "\n--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";
}
   
   

   
}