package com.mphasis.pojos;

import java.time.LocalDate;
import java.time.LocalTime;

public class Schedule {
	String scheduleId;
    LocalDate deptdate;
    LocalDate arrdate;
    LocalTime   depttime;
    LocalTime arrtime;
    String flightid;
   LocalDate current=LocalDate.now();
	public Schedule(String scheduleId,LocalDate deptdate, LocalDate arrdate, LocalTime depttime, LocalTime arrtime, String flightid) {
		super();
		this.scheduleId=scheduleId;
		this.deptdate = deptdate;
		this.arrdate = arrdate;
		this.depttime = depttime;
		this.arrtime = arrtime;
		this.flightid = flightid;
	}
	
	
	public Schedule() {
		
	}


	public String getScheduleId() {
		return scheduleId;
	}


	public void setScheduleId(String scheduleId) {
		this.scheduleId = scheduleId;
	}


	public LocalDate getDeptdate() {
		return deptdate;
	}
	public void setDeptdate(LocalDate deptdate) {
		this.deptdate = deptdate;
	}
	public LocalDate getArrdate() {
		return arrdate;
	}
	public void setArrdate(LocalDate arrdate) {
		this.arrdate = arrdate;
	}
	public LocalTime getDepttime() {
		return depttime;
	}
	public void setDepttime(LocalTime depttime) {
		this.depttime = depttime;
	}
	public LocalTime getArrtime() {
		return arrtime;
	}
	public void setArrtime(LocalTime arrtime) {
		this.arrtime = arrtime;
	}
	public String getFlightid() {
		return flightid;
	}
	public void setFlightid(String flightid) {
		this.flightid = flightid;
	}


	@Override
	public String toString() {
		return ""
				+"\n------------------------------------------------------------------------------------------------------------\n" 
				+"scheduleId : " + scheduleId + "\ndeptdate : " + deptdate + "\narrdate : " + arrdate + "\ndepttime : "
				+ depttime + "\narrtime : " + arrtime + "\nflightid : " + flightid + 
				"\n------------------------------------------------------------------------------------------------------------\n";
			}
	

}
