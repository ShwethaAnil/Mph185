package com.mphasis.pojos;

public class Route {
	String routeid;
    String source;
    String destination;
    String scheduleId;
	
	public Route(String routeid, String source, String destination, String scheduleid) {
		super();
		this.routeid = routeid;
		this.source = source;
		this.destination = destination;
		this.scheduleId=scheduleid;
	}
	
	public Route() {
		
	}

	public String getRouteid() {
		return routeid;
	}
	public void setRouteid(String routeid) {
		this.routeid = routeid;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getscheduleId() {
		return scheduleId;
	}
	public void setScheduleId(String scheduleId) {
		this.scheduleId = scheduleId;
	}
	@Override
	public String toString() {
		return ""
				+ "\n-----------------------------------------------------------------------------------\n" 
				+"\nrouteid : " + routeid + "\nsource : " + source + "\ndestination : " + destination + "\nscheduleId : "
				+ scheduleId + "\n-----------------------------------------------------------------------------------\n";
	}

}
