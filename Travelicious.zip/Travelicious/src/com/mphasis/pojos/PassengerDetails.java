package com.mphasis.pojos;

public class PassengerDetails {
	
	private String passengerid;
	private String passengername;
	private int age;
	private String gender;
	private String passportnumber;
	private String userid;
	
	
	public PassengerDetails(String passengername, int age, String gender, String passportnumber, String userid) {
		super();
		this.passengername = passengername;
		this.age = age;
		this.gender = gender;
		this.passportnumber = passportnumber;
		this.userid = userid;
	}
	public PassengerDetails(String passengerid, String passengername, int age, String gender, String passportnumber, String userid) {
		this.passengerid = passengerid;
		this.passengername=passengername;
		this.age = age;
		this.gender = gender;
		this.passportnumber=passportnumber;
		this.userid = userid;
	}
	public PassengerDetails() {
		
	}
	
	
	
	public String getPassengerid() {
		return passengerid;
	}
	public void setPassengerid(String passengerid) {
		this.passengerid = passengerid;
	}
	public String getPassengername() {
		return passengername;
	}
	public void setPassengername(String passengername) {
		this.passengername = passengername;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPassportnumber() {
		return passportnumber;
	}
	public void setPassportnumber(String passportnumber) {
		this.passportnumber = passportnumber;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	@Override
	public String toString() {
		return "\n-----------------------------------------------------------------------------------------------\n"+
				"Passengerid :" + passengerid + "\nPassengerName : " + passengername + "\nage : " + age
				+ "\ngender : " + gender + "\npassportnumber : " + passportnumber + "\nuserid : " + userid 
				+"\n-----------------------------------------------------------------------------------------------\n";
	}
	
	
	
	

}
