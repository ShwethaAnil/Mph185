package com.mphasis.pojos;

public class Airline {
	private String airlineId;
	private String airlineName;
	
	public Airline() {
		super();
	}

	public Airline(String airlineId, String airlineName) {

		super();
		this.airlineId = airlineId;
		this.airlineName = airlineName;

	}

	public String getAirlineId() {
		return airlineId;
	}
	public void setAirlineId(String airlineId) {
		this.airlineId = airlineId;
	}
	public String getAirlineName() {
		return airlineName;
	}
	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}
	@Override
	public String toString() {

		return "Airline [airlineId=" + airlineId + ", airlineName=" + airlineName + "]";

	}

}
