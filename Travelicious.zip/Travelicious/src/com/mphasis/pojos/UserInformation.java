package com.mphasis.pojos;

import java.time.LocalDate;

public class UserInformation {
	private String userId;
	private String userName;
	private String email;
	private LocalDate dob;
	private long phnNo;
	private String address;
	private String password;
	private String userType;
	
	
	public UserInformation() {

	}
	
	public UserInformation(String userName, String email, LocalDate dob, long phnNo, String address, String password) {
		super();
		
		this.userName = userName;
		this.email = email;
		this.dob = dob;
		this.phnNo = phnNo;
		this.address = address;
		this.password = password;
		this.userType="user";
	}

	public UserInformation(String userId, String userName, String email, LocalDate dob, long phnNo, String address,
			String password, String userType) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.email = email;
		this.dob = dob;
		this.phnNo = phnNo;
		this.address = address;
		this.password = password;
		this.userType = userType;
	}

	

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public long getPhnNo() {
		return phnNo;
	}

	public void setPhnNo(long phnNo) {
		this.phnNo = phnNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	@Override
	public String toString() {
		return "UserInformation [userId=" + userId + ", userName=" + userName + ", email=" + email + ", dob=" + dob
				+ ", phnNo=" + phnNo + ", address=" + address + ", password=" + password + ", userType=" + userType
				+ "]";
	}

}