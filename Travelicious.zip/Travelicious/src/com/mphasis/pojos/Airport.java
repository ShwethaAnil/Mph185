package com.mphasis.pojos;

public class Airport {
	
	
	private String airportName;
	private String country;
	private String city;
	private String airlineId;
	public Airport(String airportName, String country, String city, String airlineId, String airportId) {

	super();
	this.airportName = airportName;
	this.country = country;
	this.city = city;
	this.airlineId = airlineId;
	this.airportId = airportId;
	}

	public Airport() {
		super();
	}

	private String airportId;
	public String getAirportId() {
	return airportId;

	}

	public void setAirportId(String airportId) {
	this.airportId = airportId;

	}

	public String getAirportName() {
	return airportName;

	}

	public void setAirportName(String airportName) {
	this.airportName = airportName;

	}

	public String getCountry() {
	return country;

	}

	public void setCountry(String country) {
	this.country = country;

	}

	public String getCity() {
	return city;

	}

	public void setCity(String city) {
	this.city = city;

	}

	public String getAirlineId() {
	return airlineId;

	}

	public void setAirlineId(String airlineId) {
	this.airlineId = airlineId;
	}

	@Override

	public String toString() {

	return "Airport [airportName=" + airportName + ", country=" + country + ", city=" + city + ", airlineId="

	+ airlineId + ", airportId=" + airportId + "]";

	}

}
