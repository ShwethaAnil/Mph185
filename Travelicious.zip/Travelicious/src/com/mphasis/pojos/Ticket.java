package com.mphasis.pojos;



public class Ticket {

	static int i=0;
	public Ticket(String ticketid, String status, int seatno, String passengerid,
			String flightid, double cost) {
		super();
		this.ticketid = ticketid;
		this.status = status;
		this.seatno= seatno;
		this.passengerid=passengerid;
		this.flightid=flightid;
		this.setCost(cost);
	}
	
	public Ticket(String passengerid, String flightid, double cost) {
		super();
	
		
		this.status="Booked";
		
		this.passengerid = passengerid;
		this.flightid = flightid;
		this.cost = cost;
		i++;
	}

	

	public Ticket() {
		// TODO Auto-generated constructor stub
	}
	private String ticketid;
//	private String paymentMethod;
	private String status;
	private int seatno;
//	private String classType;
	private String passengerid;
	private String flightid;
	private double cost;
	public String getTicketid() {
		return ticketid;
	}
	public void setTicketid(String ticketid) {
		this.ticketid = ticketid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getSeatno() {
		return seatno;
	}
	public void setSeatno(int seatno) {
		this.seatno = seatno;
	}
	
	public String getPassengerid() {
		return passengerid;
	}
	public void setPassengerid(String passengerid) {
		this.passengerid = passengerid;
	}
	public String getFlightid() {
		return flightid;
	}
	public void setFlightid(String flightid) {
		this.flightid = flightid;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	@Override
	public String toString() {
		return "Ticket [ticketid=" + ticketid + ", status=" + status + ", seatno=" + seatno + ", passengerid="
				+ passengerid + ", flightid=" + flightid + ", cost=" +cost + "]";
	}
	
	
	
	
}
