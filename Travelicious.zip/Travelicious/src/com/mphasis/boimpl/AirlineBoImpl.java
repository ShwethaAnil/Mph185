package com.mphasis.boimpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.bo.AirlineBo;
import com.mphasis.dao.AirlineDao;
import com.mphasis.daoimpl.AirlineDaoImpl;
import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.Airline;

public class AirlineBoImpl implements AirlineBo {

	AirlineDao airlineDao;
	public AirlineBoImpl() {
		airlineDao = new AirlineDaoImpl();
	}
	@Override
	public List<Airline> getAirline() throws BusinessException {
		List<Airline> airlines = new ArrayList<>();
		if (airlines.isEmpty()) {
			throw new BusinessException("No Airline in the list");
		}
		return airlines;
	}

	@Override
	public Airline getAirlineById(String airlineid) throws BusinessException, SQLException {
		Airline a = airlineDao.retrieveAirlineByID(airlineid);
		if (a == null) {
			throw new BusinessException("Invalid Airline ID..");
		}
		return a;
	}

	@Override
	public void addAirline(Airline a) throws BusinessException {
		if (a.getAirlineId().matches("[AL][0-9]{3}")) {
			if (a.getAirlineName().matches("[a-zA-Z0-9]{3,15}")) {
				
				airlineDao.addAirline(a);
				
			} else {
				throw new BusinessException("Airline Name should Start with AL and length should be 3 to 15");
			}
		} else {
			throw new BusinessException("Airline Id should start with A and length should be 3 digits");
		}
	}

	@Override
	public void editAirline(String airlineid, String airlineName) throws BusinessException {
		if (airlineid.matches("[AL][0-9]{3}")) {
				if(airlineName.matches("[a-zA-Z0-9]{3,15}")) {
					
				     airlineDao.updateAirline(airlineid,airlineName);
				}else {
					throw new BusinessException("airline name should start with AL");
				}
			
		} else {
			throw new BusinessException("Airline Id should start with AL and length should be 3");
		}
	}

	@Override
	public void removeAirline(String airlineid) throws BusinessException {
		if (airlineid.matches("[AL][0-9]{3}")) {
			airlineDao.deleteAirline(airlineid);
		} else {
			throw new BusinessException("Airline id should start with AL and length should be 3 digits");
		}

}

}
