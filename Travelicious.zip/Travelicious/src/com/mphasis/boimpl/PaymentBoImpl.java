package com.mphasis.boimpl;


import java.time.YearMonth;

import com.mphasis.bo.PaymentBo;
import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.Payment;

public class PaymentBoImpl implements PaymentBo {

	@Override
	public int checkDetails(Payment p) throws BusinessException {
		int i=0;
		if(p.getCardType().equalsIgnoreCase("credit") || p.getCardType().equalsIgnoreCase("debit")) {
			if(p.getExpiryDate().isAfter(YearMonth.now() )|| p.getExpiryDate()== YearMonth.now()) {
				if(p.getCvv()<1000) {
					if(p.getHolderName().matches("[A-Za-z]{3,20}")) {
						i=1;	
					}
				}else {
					throw new BusinessException("Your CVV must be 3 Digit");
				}
			}else {
				throw new BusinessException("Your card is expired");
			}
		}
		return i;
	}

}
