package com.mphasis.boimpl;

import java.sql.SQLException;
import java.time.LocalDate;

import com.mphasis.bo.UserInfoBao;
import com.mphasis.dao.UserInfoDao;
import com.mphasis.daoimpl.UserInfoDaoImpl;
import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.UserInformation;;

public class UserInfoBaoImpl implements UserInfoBao {
	UserInfoDao userInfoDao = null;

	public UserInfoBaoImpl() {
		userInfoDao = new UserInfoDaoImpl();
	}
	@Override
	public int registerCustomer(UserInformation userInformation) throws BusinessException, SQLException{
		int i = 0;
		userInformation.setUserId(generateRandom());
		if (userInformation.getUserName().matches("^[A-Z][a-z0-9]{3,20}$")) {
			if (userInformation.getPassword().matches(".{4,}")) {
				if (userInformation.getEmail()
						.matches("^[a-zA-Z0-9.!#$%&�+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)$")) {
					if (userInformation.getUserType().equalsIgnoreCase("user")
							|| userInformation.getUserType().equalsIgnoreCase("admin")) {
						if(userInformation.getDob().isBefore(LocalDate.now())) {
						i = userInfoDao.addUser(userInformation);
						}else {
							throw new BusinessException("Date of Birth is not valid");
						}
					} else {
						throw new BusinessException(" Invalid usertype");
					}

				} else {
					throw new BusinessException("Invalid email");
				}

			} else {
				throw new BusinessException("Password should contain 4 or more characters");
			}
		} else {
			throw new BusinessException("Username accepts first uppercase and next 3-20 lowercase letters!");
		}

		return i;

	}

	
	@Override
	public UserInformation login(String username, String password) throws SQLException, BusinessException {
		UserInformation userInformation = userInfoDao.retrieveUserInfoUsingUserName(username);
		if (userInformation!=null){
			if (userInformation.getPassword().equals(password)) {
				return userInformation;
			} else {
				throw new BusinessException("User password is incorrect");
			}

		} else {
			throw new BusinessException("User is not present");
		}
	}

	@Override
	public int changePassword(String id, String password) throws SQLException, BusinessException {
		int i = 0;
		UserInformation userInformation = userInfoDao.retrieveUserInfoUsingUserId(id);
		if (userInformation.getUserId() != null) {
			if (password.matches(".{4,}")) {
				if(userInformation.getPassword().equals(password)) {
					throw new BusinessException("Password is same as previous password.");
				}else {
				i = userInfoDao.updatePasswordUsingId(id, password);
				}
			} else {
				throw new BusinessException("Password should be with 3 to 9 letters");
			}

		} else {
			throw new BusinessException("User is not available");
		}

		return i;
	}

	@Override
	public UserInformation checkEmail(String email) throws SQLException,BusinessException {
		UserInformation userInformation = userInfoDao.retrieveUserInfoUsingEmail(email);
		if (userInformation != null) {
			return userInformation;

		} else {
			throw new BusinessException("Email is not available");
		}

	}
	
	public int changeAddress(String id, String address) throws SQLException, BusinessException {
		int i = 0;
		UserInformation userInformation = userInfoDao.retrieveUserInfoUsingUserId(id);
		if (userInformation.getUserId() != null) {
			if(!(address.isEmpty())){
				i=userInfoDao.updateAddressUsingEmail(userInformation.getUserId(), address);
				
			}else {
				throw new BusinessException("address  is not valid");
			}
		} else {
			throw new BusinessException("User is not available");
		}
		
		
		return i;
		
	}

	@Override
	public int changeEmail(String userid, String newmail) throws SQLException, BusinessException{
		int i = 0;
		if (!(userid.isEmpty())) {
			i = userInfoDao.updateEmailUsingUserId(userid, newmail);
		} else {
			throw new BusinessException("userid  is not valid");
		}

		return i;
	}

	@Override
	public int changePhoneNumber(String id, long number) throws SQLException, BusinessException {
		int i = 0;
		UserInformation userInformation = userInfoDao.retrieveUserInfoUsingUserId(id);
		if (userInformation.getUserId()!= null) {
			if(number>0){
				i=userInfoDao.updatePhoneNumberUsingEmail(userInformation.getUserId(), number);
				
			}else {
				throw new BusinessException("address  is not valid");
			}
		} else {
			throw new BusinessException("Email is not available");
		}		
		return i;
		
	}
	
	
   private String generateRandom() throws SQLException {
	   
	   int random = (int)(Math.random()*900)+10;
	   String id = "U"+random;	
	   UserInformation user= userInfoDao.retrieveUserInfoUsingUserId(id);
	   if(user.getUserId()==null) {
		   return id;
	   }
	   else {
		   return generateRandom();
		   
	   } 
	}
   @Override
	public UserInformation forgotPassword(String email) throws SQLException, BusinessException {
		UserInformation userInformation = userInfoDao.retrieveUserInfoUsingEmail(email);
		if (userInformation.getEmail() != null) {
			return userInformation;
		} else {
			throw new BusinessException("Email is not available");
		}	
	}
}