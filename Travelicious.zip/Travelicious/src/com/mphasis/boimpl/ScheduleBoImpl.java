package com.mphasis.boimpl;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import com.mphasis.bo.ScheduleBo;
import com.mphasis.dao.ScheduleDao;
import com.mphasis.daoimpl.ScheduleDaoImpl;
import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.Schedule;

public class ScheduleBoImpl implements ScheduleBo {
	ScheduleDao scheduledao = null;

	

	public ScheduleBoImpl() {
		scheduledao = new ScheduleDaoImpl();
	}

	@Override
	public void addSchedule(Schedule s) throws BusinessException, SQLException {
		// TODO Auto-generated method stub

		if (s.getScheduleId().matches("^[S][0-9]{3}")) {
			if (s.getFlightid().matches("^[F][0-9]{3}")) {
				if (s.getDeptdate().isEqual(LocalDate.now())
						|| s.getDeptdate().isAfter(LocalDate.now())) { 
					if (s.getArrdate().isEqual(s.getDeptdate())
						|| s.getArrdate().isAfter(s.getDeptdate())) {
					
						    scheduledao.insertSchedule(s);
				}else
				{
					throw new BusinessException("Arrival Date should be greater than or equal to Departure Date");
				}
					} else
				{
					throw new BusinessException("Departure Date should be greater than or equal to today's date");
				}
			}
			else {
				throw new BusinessException("FlightID should start with F followed by 3 digits");
			}

		} else {
			throw new BusinessException("ScheduleID should start with S followed by 3 digits");
		}

	}

	@Override
	public void editSchedule(String scheduleId, LocalDate deptDate, LocalDate arrDate, 
			LocalTime deptTime, LocalTime arrTime,String flightId) throws BusinessException, SQLException {
		if (scheduleId.matches("^[S][0-9]{3}")) {
			if (flightId.matches("^[F][0-9]{3}")) {
				if (deptDate.isEqual(LocalDate.now()) || deptDate.isAfter(LocalDate.now())) { 
					if (arrDate.isEqual(deptDate) || arrDate.isAfter(deptDate)) {
					
		scheduledao.updateSchedule(scheduleId, deptDate, arrDate,  deptTime, arrTime,flightId);
					}else
					{
						throw new BusinessException("Arrival Date should be greater than or equal to Departure Date");
					}
						} else
					{
						throw new BusinessException("Departure Date should be greater than or equal to today's date");
					}
				}
				else {
					throw new BusinessException("FlightID should start with F followed by 3 digits");
				}

			} else {
				throw new BusinessException("ScheduleID should start with S followed by 3 digits");
			}

		}
		
	

	@Override
	public void removeSchedule(String scheduleId) throws BusinessException {
		// TODO Auto-generated method stub
		if (scheduleId.matches("^[S][0-9]{3}")) {
			scheduledao.deleteSchedule(scheduleId);
		} else {
			throw new BusinessException("Invalid scheduleid");
		}
	}

	@Override
	public Schedule getScheduleById(String scheduleId) throws BusinessException, SQLException {
		// TODO Auto-generated method stub
		Schedule s = scheduledao.retrieveScheduleById(scheduleId);
		if (s == null) {
			throw new BusinessException("No schedule in the list with the mentioned Schedule ID");
		}
		return s;
	}

	@Override
	public List<Schedule> getSchedules() throws BusinessException, SQLException {
		// TODO Auto-generated method stub
		List<Schedule> schedules = scheduledao.retrieveSchedules();
		if (schedules.isEmpty()) {
			throw new BusinessException("No schedule in the list");
		}
		return schedules;
	}

	@Override
	public Schedule getScheduleByDept(String deptDate) throws BusinessException, SQLException {
		Schedule s = scheduledao.getScheduleByDept(deptDate);
		if (s == null) {
			throw new BusinessException("No schedule in the list with the mentioned date");
		}
		return s;
	}
	
	@Override
	public void editScheduleTime(String scheduleId, LocalTime deptTime,LocalTime arrTime) throws BusinessException, SQLException {
		if (scheduleId.matches("^[S][0-9]{3}")) {
		scheduledao.updateScheduleTime(scheduleId,  deptTime,arrTime);
		
		} else {
			throw new BusinessException("ScheduleID should start with S followed by 3 digits");
		}

	}

}
