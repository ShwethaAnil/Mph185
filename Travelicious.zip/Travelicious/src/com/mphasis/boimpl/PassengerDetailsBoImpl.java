package com.mphasis.boimpl;

import java.sql.SQLException;
import java.util.List;

import com.mphasis.bo.PassengerDetailsBo;
import com.mphasis.dao.PassengerDetailsDao;
import com.mphasis.daoimpl.PassengerDetailsDaoImpl;
import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.PassengerDetails;
public class PassengerDetailsBoImpl implements PassengerDetailsBo {
	PassengerDetailsDao passengerDao=null;
	public PassengerDetailsBoImpl() {
		passengerDao=new PassengerDetailsDaoImpl();
	}

	@Override
	public List<PassengerDetails> getPassenger() throws BusinessException {
		List<PassengerDetails> passengers=passengerDao.retrievePassengers();
		if(passengers.isEmpty()) {
			throw new BusinessException("No passengers present");
		}
		return passengers;
	}

	@Override 
	public void addPassenger(PassengerDetails p) throws BusinessException {
		p.setPassengerid(generatePassengerId());
		if(p.getPassengerid().matches("^[P][0-9]{0,3}")) {
			if(p.getPassengername().matches("[a-zA-Z0-9]{2,30}")) {
				if(p.getAge()>0) {
					if(p.getGender().equals("Male") || p.getGender().equals("Female") || p.getGender().equals("Other")) {
						try {
							passengerDao.addPassenger(p);
						}catch(NullPointerException e) {
							e.getMessage();
						}
							
					}else {
						throw new BusinessException("Invalid input for Gender");
					}
				}else {
					throw new BusinessException("Age must be valid number");
				}
			}else {
				throw new BusinessException("name must be of letters");
			}
		}else {
			throw new BusinessException("Id must start with P followed by numbers");
		}

	}

	private String generatePassengerId() {
		int random = (int)(Math.random()*1000)+10;
		String pId = "P"+random;
		PassengerDetails pDetails;
		try {
			 pDetails= passengerDao.retrievePassengerById(pId);
			 if(pDetails.getPassengerid()==null) {
				 return pId;
			 }
			 else {
				 return generatePassengerId();
			 }
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return pId;
	}

	@Override
	public PassengerDetails retrievePassengerById(String passengerid) throws BusinessException, SQLException {
		PassengerDetails p = passengerDao.retrievePassengerById(passengerid);
		if(p==null) {
			throw new BusinessException("Passenger Id is not present");
		}
		return p;
	}

	@Override
	public void editPassengerById(String passengerid, int age) throws BusinessException {
		if(passengerid.matches("^[P][0-9]{0,3}")) {
			if(age>0) {
				passengerDao.updatePassenger(passengerid, age);
			}else {
				throw new BusinessException("Age must be valid number");
			}
		}else {
			throw new BusinessException("Id must start with P followed by numbers");
		}

	}

	@Override
	public void removePassenger(String passengerid) throws BusinessException {
		if(passengerid.matches("^[P][0-9]{0,3}")) {
			passengerDao.deletePassenger(passengerid);
		}else {
			throw new BusinessException("Id must start with P followed by numbers");
		}

	}

}
