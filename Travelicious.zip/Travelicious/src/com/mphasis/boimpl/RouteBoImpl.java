package com.mphasis.boimpl;

import java.sql.SQLException;

import java.util.List;

import com.mphasis.bo.RouteBo;
import com.mphasis.dao.RouteDao;
import com.mphasis.daoimpl.RouteDaoImpl;
import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.Route;

public class RouteBoImpl implements RouteBo {
	RouteDao routedao = null;
	
	 public RouteBoImpl()
	 {
		 routedao = new RouteDaoImpl();
	 }
	@Override
	public void addRoute(Route r) throws BusinessException, SQLException {
		
			if(r.getRouteid().matches("^[R][0-9]{3}"))
						{
		         	if(r.getSource().matches("[a-zA-z]{3,15}"))	
		            	{
		            		if(r.getDestination().matches("[a-zA-z]{3,15}"))	
		            		 
		            		{
		            			if(r.getscheduleId().matches("^[S][0-9]{3}"))
		            			{
		            			   routedao.insertRoute(r);
								
							    }
		            			else
								{
									throw new BusinessException("ScheduleId should start with S ");
								}}
		                        else
								{
							    throw new BusinessException("Destination should only be letters");
								}
								
							 }else
							{
							throw new BusinessException("Source should only be letters");
							}
				          }else
						{
						throw new BusinessException("RouteID should start with R");
					}
				}
				
				
	

	@Override
	public void editRoute(String routeid, String source, String destination, String scheduleId)
			throws BusinessException{
		if(routeid.matches("^[R][0-9]{3}")) {
			if(source.matches("[a-zA-Z]{3,15}"))	{
				if(destination.matches("[a-zA-z]{3,15}")) {
					if(scheduleId.matches("^[S][0-9]{3}")) {
				routedao.editRoute(routeid, source, destination, scheduleId);	
					 }else{
						throw new BusinessException("ScheduleId should start with S ");
					}
					}else{
				    throw new BusinessException("Destination should only be letters");
					}
				 }else{
				throw new BusinessException("Source should only be letters");
				}
	          }else{
			throw new BusinessException("RouteID should start with R");
		   }
          }
	



	@Override
	public void removeRoute(String routeId) throws BusinessException {
		// TODO Auto-generated method stub
		if(routeId.matches("^[R][0-9]{3}")){
			routedao.deleteRoute(routeId);
		}
		else
		{
			throw new BusinessException("Invalid routeid");
		}
	}

	
	@Override
	public Route getRouteById(String routeId) throws BusinessException, SQLException  {
		// TODO Auto-generated method stub
		Route r = routedao.retrieveRouteById(routeId);
		if(r == null)
		{
			throw new BusinessException("No Route with the mentioned routeid ");
		}
		return r;
	}

	@Override
	public List<Route> getRoutes() throws BusinessException {
		// TODO Auto-generated method stub
			List<Route> routes = routedao.retrieveRoutes();
			if(routes.isEmpty())
			{
				throw new BusinessException("No routes in the list");
			}
			return routes;
		}
	@Override
	public Route getRouteBySourceDest(String source, String destination) throws BusinessException, SQLException {
		Route r = routedao.getRouteBySourceDest(source, destination);
		if(r == null)
		{
			throw new BusinessException("No Route with the mentioned Source and Destination");
		}
		return r;
	}
}
