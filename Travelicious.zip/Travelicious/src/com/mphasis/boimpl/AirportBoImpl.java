package com.mphasis.boimpl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.bo.AirportBo;
import com.mphasis.dao.AirportDao;
import com.mphasis.daoimpl.AirportDaoImpl;
import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.Airport;

public class AirportBoImpl implements AirportBo {
	AirportDao airportDao;
	public AirportBoImpl() {
		airportDao = new AirportDaoImpl();
	}
	
	@Override
	public List<Airport> getAirport() throws BusinessException {
		List<Airport> airports = new ArrayList<>();
		if (airports.isEmpty()) {
			throw new BusinessException("No Airport in the list");
		}
		return airports;
	}
	

	@Override
	public Airport getAirportById(String airportid) throws BusinessException, SQLException {
		Airport a = airportDao.retrieveAirportByID(airportid);
		if (a == null) {
			throw new BusinessException("Invalid Airport ID..");
		}
		return a;
	}

	@Override
	public void addAirport(Airport a) throws BusinessException {
		if (a.getAirportId().matches("[AP][0-9]{3}")) {
			if (a.getAirportName().matches("[a-zA-Z0-9]{3,15}")) {
				if (a.getAirlineId().matches("[P][0-9]{3}")) {
					if (a.getCountry().matches("[a-zA-Z0-9]{3,15}")) {
						if (a.getCity().matches("[a-zA-Z0-9]{3,15}")) {
						     airportDao.insertAirportDetails(a);
							// System.out.println("Product added at index "+index);
						} else {
							throw new BusinessException("City length should be more 3");
						}
					} else {
						throw new BusinessException("country length should be more than 3");
					}
				} else {
					throw new BusinessException("Airline Id should start with A and length should be 3 digits");
				}
			} else {
				throw new BusinessException("Airport name  length should be minimum 3 digits");
			}
		} else {
			throw new BusinessException("Airport Id should start with AP and length should be mininmum 3 digits");
		}


	}

	@Override
	public void editAirport(String airportid, String airportName, String airlineid) throws BusinessException {
		if (airportid.matches("[AP][0-9]{3}")) {
			if(airportName.matches("[a-zA-Z0-9]{3,15}")) {
				
			     airportDao.updateAirportDetails(airportid,airportName,airlineid);
			}else {
				throw new BusinessException("airport name should contains only letters");
			}
		
	} else {
		throw new BusinessException("Airport Id should start with AP and length should be 3");
	}
}

	@Override
	public void removeAirline(String airportid) throws BusinessException {
		if (airportid.matches("[AP][0-9]{3}")) {
			airportDao.deleteAirlineDetails(airportid);
		} else {
			throw new BusinessException("Airport id should start with P and length should be 3 digits");
		}
	}

}
