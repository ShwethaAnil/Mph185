package com.mphasis.boimpl;

import java.sql.SQLException;
import java.time.LocalDate;

import java.util.Comparator;
import java.util.List;

import com.mphasis.bo.FlightBo;
import com.mphasis.dao.FlightDao;
import com.mphasis.daoimpl.FlightDaoImpl;
import com.mphasis.dto.SearchFlightDetails;
import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.Flight;






public class FlightBoImpl implements FlightBo{
	
	FlightDao flightDao = null;
	
	public FlightBoImpl() {
		flightDao = new FlightDaoImpl();
	}

	@Override
	public List<Flight> getFlights() throws BusinessException {
		List<Flight> flights = flightDao.retrieveFlights();
		if (flights.isEmpty()) {
			throw new BusinessException("No Flights to show");
		}
		return flights;
	}

	@Override
	public Flight getFlightById(String flightId) throws BusinessException, SQLException {
		Flight f = flightDao.retrieveFlightById(flightId);
		if (f.getFlightId()==null) {
			throw new BusinessException("Invalid Flight ID..TRY AGAIN");
		}
		return f;
	}

	@Override
	public void addFlight(Flight f) throws BusinessException {
		if (f.getFlightId().matches("[F][0-9]{3}")) {
			if (f.getNumOfSeats()>0) {
				if(f.getTypeOfClass().equalsIgnoreCase("Business")||f.getTypeOfClass().equalsIgnoreCase("Economy")||f.getTypeOfClass().equalsIgnoreCase("First")) {
				if ( f.getMinFare()>0){
					if (f.getAirlineId().matches("[AL]{2}[0-9]{3}")) {
						
						flightDao.insertFlight(f);
						
					} else {
					throw new BusinessException("Airline Id should start with AL and length should be 3");
					}					
						
				} else {
				throw new BusinessException("Fare should be greater than zero");
				}
				}else {
					throw new BusinessException("Type of class is should be either first,business or economy");
				}
			} else {
				throw new BusinessException("Number of seats should be greater than zero");
			}
		} else {
			throw new BusinessException("Flight Id should start with F and length should be 3");
		}
		
	}

	@Override
	public void updateSeatsByFlightId(String flightId, int numOfSeats) throws BusinessException {
		if (flightId.matches("[F][0-9]{3}")) {
			if (numOfSeats > 0) {
				 flightDao.updateSeatsByFlightId(flightId, numOfSeats);
			} else {
				throw new BusinessException("seats should be greater than 0");
			}
		} else {
			throw new BusinessException("Flight Id should start with F and length should be 3");
		}
		
	}

	@Override
	public void removeFlight(String flightId) throws BusinessException {
		if (flightId.matches("[F][0-9]{3}")) {
			flightDao.deleteFlight(flightId);
		} else {
			throw new BusinessException("Flight Id should start with F and length should be 3");
		}
		
	}

	@Override
	public void updateFareByFlightId(String flightId, double minFare) throws BusinessException {
		if (flightId.matches("[F][0-9]{3}")) {
			if (minFare>0) {
				 flightDao.updateFareByFlightId(flightId, minFare);
			} else {
				throw new BusinessException("Fare should be greater than zero");
			}
		} else {
			throw new BusinessException("Flight Id should start with F and length should be 3");
		}
		
	}

	@Override
	public void updateClassByFlightId(String flightId, String typeOfClass,double minFare) throws BusinessException {
		if (flightId.matches("[F][0-9]{3}")) {
			if (typeOfClass.equalsIgnoreCase("Business")||typeOfClass.equalsIgnoreCase("Economy")||typeOfClass.equalsIgnoreCase("First")){
				if(minFare>0) {
				 flightDao.updateClassByFlightId(flightId, typeOfClass,minFare);
				}else {
					throw new BusinessException("fare should be greater than zero");
				}
			} else {
				throw new BusinessException("type of class should be either Business,Economy or First");
			}
		} else {
			throw new BusinessException("Flight Id should start with F and length should be 3");
		}
		
	}

	@Override
	public List<SearchFlightDetails> getSearchDetails(String source, String destination, String deptdate)
			throws BusinessException, SQLException {
		List<SearchFlightDetails> searchFlights;
		LocalDate deptDate= LocalDate.parse(deptdate);
		if (deptDate.isEqual(LocalDate.now())|| deptDate.isAfter(LocalDate.now())) {	
			searchFlights = flightDao.retriveDetailsBySourceDestandDate(source, destination, deptdate);
			if(searchFlights.isEmpty()) {
				throw new BusinessException("No Flights Avaliable for your Search");
			}
		}
		else {
			throw new BusinessException("Dept Date should be greater than  or equal to today's date");
		}
		return searchFlights;
	}
	
	@Override
	public void sortByFare(List<SearchFlightDetails> sfs) throws BusinessException {
		sfs.stream()
		.sorted(Comparator.comparing(SearchFlightDetails :: getMinfare))
		.forEach(System.out::println);
			
	}

}
