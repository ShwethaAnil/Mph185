package com.mphasis.boimpl;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.util.Iterator;
import java.util.List;

import com.mphasis.bo.TicketBo;
import com.mphasis.dao.TicketDao;
import com.mphasis.daoimpl.TicketDaoImpl;
import com.mphasis.exception.BusinessException;
import com.mphasis.pojos.Ticket;

public class TicketBoImpl implements TicketBo {

	TicketDao ticketDao = null;

	public TicketBoImpl() {
		ticketDao = new TicketDaoImpl();
	}

	@Override
	public List<Ticket> getTickets() throws BusinessException {
		List<Ticket> tickets = ticketDao.retrieveTickets();
		if (tickets.isEmpty()) {
			throw new BusinessException("No ticket present");
		}
		return tickets;
	}

	@Override
	public void addTicket(Ticket t) throws BusinessException, SQLException {
		t.setTicketid(generateTicket());
		t.setSeatno(generateSeatNo());
		if (t.getTicketid().matches("^[T][0-9]{0,3}")) {
			if (t.getStatus().equalsIgnoreCase("Booked") || t.getStatus().equalsIgnoreCase("Cancelled")) {
				if (t.getCost() > 0) {
					ticketDao.addTicket(t);
				} else {
					throw new BusinessException("Cost is invalid");
				}

			} else {
				throw new BusinessException("status should either be booked or Cancelled");
			}
		} else {
			throw new BusinessException("Id must start with T followed by numbers");
		}

	}

	@Override
	public Ticket retrieveTicketById(String ticketid) throws BusinessException, SQLException {
		Ticket t = ticketDao.retrieveTicketById(ticketid);
		if (t == null) {
			throw new BusinessException("Ticket is not present");
		}
		return t;
	}

	@Override
	public void editStatusByTicketId(String ticketid, String status) throws BusinessException {
		if (ticketid.matches("^[T][0-9]{0,3}")) {
			if (status.equalsIgnoreCase("Booked") || status.equalsIgnoreCase("Cancelled")) {
				ticketDao.updateStatusByTicketId(ticketid, status);
			} else {
				throw new BusinessException("status should either be booked or Cancelled");
			}
		} else {
			throw new BusinessException("Id must start with T followed by numbers");
		}
	}

	@Override
	public void removeTicket(String ticketid) throws BusinessException {
		if (ticketid.matches("^[T][0-9]{0,3}")) {
			ticketDao.deleteTicket(ticketid);
		} else {
			throw new BusinessException("Id must start with T followed by numbers");
		}

	}

	@Override
	public void editCostByTicketId(String ticketid, double cost, String deptdate, String fclass)
			throws BusinessException, SQLException {
		LocalDate today = LocalDate.now();
		LocalDate travelling = LocalDate.parse(deptdate);
		Period p = Period.between(travelling, today);
		if (ticketid.matches("^[T][0-9]{0,3}")) {
			if (fclass.equalsIgnoreCase("Business")) {
				if (cost >= 0) {
					if (p.getMonths() >= 3)
						ticketDao.updateCostByTicketId(ticketid, cost);
					else if (p.getDays() >= 7)
						ticketDao.updateCostByTicketId(ticketid, cost + 1000);
					else if (p.getDays() <= 3)
						ticketDao.updateCostByTicketId(ticketid, cost + 2000);
				} else {
					throw new BusinessException("Cost is invalid");
				}
			} else if (fclass.equalsIgnoreCase("Economy")) {
				if (cost >= 0) {
					if (p.getMonths() >= 3)
						ticketDao.updateCostByTicketId(ticketid, cost);
					else if (p.getDays() >= 7 && p.getDays() > 3)
						ticketDao.updateCostByTicketId(ticketid, cost + 1500);
					else if (p.getDays() <= 3)
						ticketDao.updateCostByTicketId(ticketid, cost + 2500);
				} else {
					throw new BusinessException("Cost is invalid");
				}
			}
		} else {
			throw new BusinessException("Id must start with T followed by numbers");
		}

	}

	private String generateTicket() throws SQLException {

		int random = (int) (Math.random() * 900) + 10;
		String id = "T" + random;
		Ticket ticket = ticketDao.retrieveTicketById(id);
		if (ticket.getTicketid() == null) {
			return id;
		} else {
			return generateTicket();

		}
	}

	private int generateSeatNo() {
		int seatNo = (int) (Math.random() * 89) + 10;
		List<Ticket> tickets = ticketDao.retrieveTickets();
		for (Iterator<Ticket> iterator = tickets.iterator(); iterator.hasNext();) {
			Ticket ticket = (Ticket) iterator.next();
			if (ticket.getSeatno() == seatNo) {
				generateSeatNo();
			}
		}
		return seatNo;
	}

}
