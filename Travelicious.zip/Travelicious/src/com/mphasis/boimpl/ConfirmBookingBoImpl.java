package com.mphasis.boimpl;

import java.sql.SQLException;

import java.util.Comparator;
import java.util.List;

import com.mphasis.bo.ConfirmBookingBo;
import com.mphasis.dao.ConfirmBookingDao;
import com.mphasis.daoimpl.ConfirmBookingDaoImpl;
import com.mphasis.dto.ConfirmBooking;
import com.mphasis.exception.BusinessException;



public class ConfirmBookingBoImpl implements ConfirmBookingBo {
	ConfirmBookingDao bookingDao = null;
	public ConfirmBookingBoImpl() {
      bookingDao = new ConfirmBookingDaoImpl();
	}
		
		public List<ConfirmBooking> getBookings(String userid)
				throws BusinessException, SQLException {
			List<ConfirmBooking> bookings;
			if (userid != null) {	
				bookings = bookingDao.retriveticketDetailsById(userid);
				if(bookings.isEmpty()) {
					throw new BusinessException("No ticket booked");
				}
			}
			else {
				throw new BusinessException("No tickets booked");
			}
			return bookings;
		}
		Comparator<ConfirmBooking> byDate = (c1, c2) -> {
			  if (c1.getDeptdate().isAfter(c2.getDeptdate())) return -1; 
			  else return 1;
			};
			 

		@Override
		public void sortByDate(List<ConfirmBooking> cfs) throws BusinessException {
			cfs.stream().sorted(byDate.reversed())
			.forEach(System.out::println);
			
		}
		

}
